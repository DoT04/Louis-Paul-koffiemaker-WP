<?php

/*
            Template Name: Abonnement Page

*/



?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Louis Paul koffiemaker</title>
    <?php wp_head(); ?>
</head>

<body>
    <!-- /main nav -->

    <a href="#menu" class="menu">
        <span class="fa fa-reorder"></span>
    </a>
    <!-- <img src="images/logo2.png" alt="" class="logo"> -->

    <nav class="mainnav" role="mainnav">
        <ul class="links list-unstyled">
            <li><a href="../index.html">Home</a></li>
            <li><a href="../bestel/bestel.html#proefpakket">Proefpakket</a></li>
            <li><a href="../abonnement/abonnement.html#abonnement">Koffieabonnement</a></li>
            <li><a href="../bestel/bestel.html#single-origin">Koffiebonen SINGLE ORIGIN</a></li>
            <li><a href="../overons/overons.html">Over ons</a></li>
            <li><a href="../klantenservice/klantenservice.html" title="">Klantenservice</a></li>
        </ul>
    </nav>

  <header>
  <div class="overons-titel-cont overons-titel-img" style="background-image: url(../images/img9.jpg)">
        <div class="relative container">
            <div class="row">

                <div class="col-md-8 wow animate__animated animate__fadeInDownBig" data-wow-duration="1500ms"
                data-wow-delay="100ms" id="abonnement">
                    <h1 class="overons-titel">KOFFIEABONNEMENT</h1>
                    <div class="overons-subtitel">
                        unieke smaken, unieke koffiebonen voor een uitzonderlijke koffie
                    </div>
                </div>


            </div>
        </div>
    </div>

  </header>


    <!-- KOFFIEABONNEMENT1 -->
    <div class="page-section abo-cont">
        <h2 class="abo-titel">stel zelf je abonnement samen</h2>
        <h3 class="abo-subtitel"><span class="abo-subtitel-nummer">1</span>kies je abonnement</h3>
        <div class="container">
            <div class="row mb-5">



                <div class="overons-cont1 col-md-4 col-sm-4 wow animate__animated animate__fadeInUp">
                    <div class="overons-image">
                        <img class="mx-auto d-block" src="../images/img4.jpg" alt="img" width="120" height="120">
                    </div>
                    <h3>GEDURENDE LANGE TIJD KOFFIEABONNEMENT</h3>
                    <span class="bold">vanaf &euro;19</span><br> elke twee weken
                    <div class="abo-cont2">
                        <br>
                        <p>2 x 250 gr/levering - incl. verz<br>Je kan op elk moment pauzeren, wijzigen of stopzetten.<br>Jij bepaalt.</p>
                    </div>
                    <div class="mt-30">
                        <a class="button medium thin hover-dark" href="#hoeveelheid">KIES</a>
                    </div>


                </div>
                <div class="overons-cont1 col-md-4 col-sm-4 wow animate__animated animate__fadeInUp">
                    <div class="overons-image">
                        <img class="mx-auto d-block" src="../images/img4.jpg" alt="img" width="120" height="120">
                    </div>
                    <h3>3 MAANDEN-ABONNEMENT</h3>
                    <span class="bold">vanaf &euro;114</span><br>6 leveringen + gratis ontbijtplankje
                    <div class="abo-cont2">
                        <br>
                        <p>2 x 250 gr/levering - incl. verz<br>Je kan op elk moment pauzeren, wijzigen of stopzetten.<br>Jij bepaalt.</p>
                    </div>
                    <div class="mt-30">
                        <a class="button medium thin hover-dark" href="#hoeveelheid">KIES</a>
                    </div>


                </div>
                <div class="overons-cont1 col-md-4 col-sm-4 wow animate__animated animate__fadeInUp">
                    <div class="overons-image">
                        <img class="mx-auto d-block" src="../images/img4.jpg" alt="img" width="120" height="120">
                    </div>
                    <h3>6 MAANDEN-ABONNEMENT</h3>
                    <span class="bold">vanaf &euro;228</span><br>12 leveringen + 2 gratis ontbijtplankjes
                    <div class="abo-cont2">
                        <br>
                        <p>2 x 250 gr/levering - incl. verz<br>Je kan op elk moment pauzeren, wijzigen of stopzetten.<br>Jij bepaalt.</p>
                    </div>
                    <div class="mt-30">
                        <a class="button medium thin hover-dark" href="#hoeveelheid">KIES</a>
                    </div>


                </div>




            </div>
            <!-- end of abo nr1 -->

        </div>


        <!-- start nr 2 -->
        <h3 class="abo-subtitel"><span class="abo-subtitel-nummer" id="hoeveelheid">2</span>kies je hoeveelheid</h3>

        <div class="container">
            <div class="row mb-5">



                <div class="overons-cont1 col-md-6 col-sm-6 wow animate__animated animate__fadeInLeftBig">

                    <h3>2 x 250 gr</h3>

                    <div class="abo-cont3">
                        <br>
                        <p>genoeg koffie voor 2 weken voor 1-2 personen</p>
                    </div>
                    <div class="mt-30">
                        <a class="button medium thin hover-dark" href="#koffiesoort">KIES</a>
                    </div>


                </div>
                <div class="overons-cont1 col-md-6 col-sm-6 wow animate__animated animate__fadeInLeftBig">

                    <h3>4 x 250 gr</h3>

                    <div class="abo-cont4">
                        <br>
                        <p>genoeg koffie voor 2 weken voor 2-3 personen </p>
                    </div>
                    <div class="mt-30">
                        <a class="button medium thin hover-dark" href="#koffiesoort">KIES</a>
                    </div>


                </div>





            </div>
            <!-- end of abo nr1 -->

        </div>



        <!-- end nr 2 -->
        <!-- start nr 3 -->
        <h3 class="abo-subtitel" id="koffiesoort"><span class="abo-subtitel-nummer">3</span>kies je Single Origin koffie
        </h3>
        <div class="container mt-5">



            <!-- start abo nr 3 -->

            <div class="row row-equal">

                <div class="col-md-3">
                    <div class="col-md-3  pb-4" id="img-abo1">
                        <img src="../images/img1.jpg" class="rounded mx-auto d-block" alt="Responsive image" width="90"
                            height="120">
                    </div>

                    <!-- CONTENT 1-->
                    <div class="col-md-12 col-sm-12  mb-5 bestel-cont2" id="single-origin1">

                        <h3 class="mt-0 mb-30 bold">GUATEMALA EL ZAPOTE</h3>

                        <hr class="mt-0 mb-30">
                        <div class="row">

                            <div class="col-xs-6  mt-0 mb-30">
                                <!-- <del>&euro;130.00</del> -->
                                <strong class="item-price">&euro;8.80</strong>
                            </div>



                        </div>

                        <hr class="mt-0 mb-30">

                        <div class="col-equal">
                            Finca El Zapote is een bijzondere koffie met een traditioneel karakter. Een zoete koffie
                            met
                            tonen van karamel en hazelnoot en met een licht sprankelende frisheid. Met een volle,
                            zoete
                            en romige afdronk is dit de ideale koffie om de hele dag door te drinken. Heerlijk als
                            espresso en lungo maar ook geschikt als filterkoffie.
                        </div>



                        <div class="row">
                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Gewicht</option>
                                        <option>250 gr</option>
                                        <!-- <option>1 kg</option> -->

                                    </select>
                                </form>
                            </div>

                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Maling</option>
                                        <option>Bonen</option>
                                        <option>Maling: espresso</option>
                                        <option>Maling: snelfilter</option>
                                    </select>
                                </form>
                            </div>
                        </div>



                        <!-- ADD TO CART 1-->
                        <div class="row">

                            <div class="col-xs-4 col-sm-2 col-md-2  mb-30 input-counter">
                                <form method="post" action="#" class="form"></form>
                                <input type="number" class="input-border" min="1" max="100" value="1">
                            </div>
                            <div class="col-xs-4 col-sm-2 col-md-2 mb-30 ml-5">
                                <div>
                                    <div class="pl-5 ml-5">
                                        <a class="button medium thin hover-dark" href="#verzending">KIES</a>
                                    </div>

                                </div>
                            </div>

                        </div>





                    </div>
                </div>
                <!-- end of single single-origin1 -->

                <!-- start SO2 -->
                <div class="col-md-3">
                    <div class="col-md-3  pb-4" id="img-abo2">
                        <img src="../images/img2.jpg" class="rounded mx-auto d-block" alt="Responsive image" width="90"
                            height="120">
                    </div>

                    <!-- CONTENT 2-->
                    <div class="col-md-12 col-sm-12  mb-5 bestel-cont2" id="single-origin2">

                        <h3 class="mt-0 mb-30 bold">COSTA RICA TARRAZU</h3>

                        <hr class="mt-0 mb-30">
                        <div class="row">

                            <div class="col-xs-6  mt-0 mb-30">
                                <!-- <del>$130.00</del> -->
                                <strong class="item-price">&euro;8.80</strong>
                            </div>



                        </div>

                        <hr class="mt-0 mb-30">

                        <div class="col-equal">
                            De Costa Rica Tarrazu is een milde, zoete, gebalanceerde koffie met tonen van noten en
                            chocolade. Een heerlijke, plezierige koffie om de hele dag door te drinken. Heerlijk als
                            espresso, maar ook prima geschikt voor filterkoffie.
                        </div>



                        <div class="row">
                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Gewicht</option>
                                        <option>250 gr</option>
                                        <!-- <option>1 kg</option> -->

                                    </select>
                                </form>
                            </div>

                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Maling</option>
                                        <option>Bonen</option>
                                        <option>Maling: espresso</option>
                                        <option>Maling: snelfilter</option>
                                    </select>
                                </form>
                            </div>
                        </div>



                        <!-- ADD TO CART 2-->
                        <div class="row">

                            <div class="col-xs-4 col-sm-2 col-md-2  mb-30 input-counter">
                                <form method="post" action="#" class="form"></form>
                                <input type="number" class="input-border" min="1" max="100" value="1">
                            </div>
                            <div class="col-xs-4 col-sm-6 col-md-2 mb-30 ml-5">
                                <div>
                                    <div class="pl-5 ml-5">
                                        <a class="button medium thin hover-dark" href="#verzending">KIES</a>
                                    </div>

                                </div>
                            </div>

                        </div>





                    </div>
                </div>
                <!-- end SO2 -->

                <!-- start SO3 -->
                <div class="col-md-3">
                    <div class="col-md-3  pb-4" id="img-abo3">
                        <img src="../images/img1.jpg" class="rounded mx-auto d-block" alt="Responsive image" width="90"
                            height="120">
                    </div>

                    <!-- CONTENT 3-->
                    <div class="col-md-12 col-sm-12 mb-5 bestel-cont2" id="single-origin3">

                        <h3 class="mt-0 mb-30 bold">PERU EL PALTO</h3>

                        <hr class="mt-0 mb-30">
                        <div class="row">

                            <div class="col-xs-6  mt-0 mb-30">
                                <!-- <del>$130.00</del> -->
                                <strong class="item-price">&euro;8.80</strong>
                            </div>



                        </div>

                        <hr class="mt-0 mb-30">

                        <div class="col-equal">
                            De Peru El Palto is een heerlijke, zachte, romige, zoete koffie met tonen van
                            melkchocolade,
                            toffee en geroosterde pecannoten. Door zijn lage zuurgraad is deze koffie ideaal
                            geschikt
                            voor lungo, espresso en als basis voor een cappuccino. Deze koffie kun je de hele dag
                            door
                            blijven drinken.
                        </div>



                        <div class="row">
                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Gewicht</option>
                                        <option>250 gr</option>
                                        <!-- <option>1 kg</option> -->

                                    </select>
                                </form>
                            </div>

                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Maling</option>
                                        <option>Bonen</option>
                                        <option>Maling: espresso</option>
                                        <option>Maling: snelfilter</option>
                                    </select>
                                </form>
                            </div>
                        </div>



                        <!-- ADD TO CART 3-->
                        <div class="row">

                            <div class="col-xs-4 col-sm-2 col-md-2  mb-30 input-counter">
                                <form method="post" action="#" class="form"></form>
                                <input type="number" class="input-border" min="1" max="100" value="1">
                            </div>
                            <div class="col-xs-4 col-sm-6 col-md-2 mb-30 ml-5">
                                <div>
                                    <div class="pl-5 ml-5">
                                        <a class="button medium thin hover-dark" href="#verzending">KIES</a>
                                    </div>

                                </div>
                            </div>

                        </div>





                    </div>
                </div>
                <!-- end SO3 -->


                <!-- start SO4 -->
                <div class="col-md-3">

                    <div class="col-md-3 pb-4" id="img-abo4">
                        <img src="../images/img2.jpg" class="rounded mx-auto d-block" alt="Responsive image" width="90"
                            height="120" style="display: block;margin: auto;">
                    </div>

                    <!-- CONTENT 4-->
                    <div class="col-md-12 col-sm-12 mb-5 bestel-cont2">

                        <h3 class="mt-0 mb-30 bold">COLOMBIA FINCA SANTAFE</h3>

                        <hr class="mt-0 mb-30">
                        <div class="row">

                            <div class="col-xs-6  mt-0 mb-30">
                                <!-- <del>$130.00</del> -->
                                <strong class="item-price">&euro;8.80</strong>
                            </div>



                        </div>

                        <hr class="mt-0 mb-30">

                        <div class="col-equal">
                            Deze Direct Trade koffie is complex en veelzijdig. Een heerlijke, romige, stevige koffie
                            met
                            een volle body met tonen van pure chocolade, karamel en zoete kersen. Een koffie met een
                            zoete afdronk en een vol mondgevoel. Absoluut een topper!
                        </div>



                        <div class="row">
                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Gewicht</option>
                                        <option>250 gr</option>
                                        <!-- <option>1 kg</option> -->

                                    </select>
                                </form>
                            </div>

                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Maling</option>
                                        <option>Bonen</option>
                                        <option>Maling: espresso</option>
                                        <option>Maling: snelfilter</option>
                                    </select>
                                </form>
                            </div>
                        </div>



                        <!-- ADD TO CART 4-->
                        <div class="row">

                            <div class="col-xs-4 col-sm-2 col-md-2  mb-30 input-counter">
                                <form method="post" action="#" class="form"></form>
                                <input type="number" class="input-border" min="1" max="100" value="1">
                            </div>
                            <div class="col-xs-4 col-sm-6 col-md-2 mb-30 ml-5">
                                <div>
                                    <div class="pl-5 ml-5">
                                        <a class="button medium thin hover-dark" href="#verzending">KIES</a>
                                    </div>
                                </div>
                            </div>

                        </div>






                    </div>
                </div>
                <!-- end SO4 -->









            </div>
        </div>
        <!-- end nr3 -->


        <!-- start nr 4 -->
        <h3 class="abo-subtitel" id="verzending"><span class="abo-subtitel-nummer">4</span>verzending
        </h3>
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-6  wow animate__animated animate__fadeInLeftBig mb-0">



                    <div>

                        <p>kies je startdatum </p>
                    </div>
                    <div class="mt-3">
                        <a class="button medium thin hover-dark" href="#koffiesoort">dd/dd/dddd</a>
                    </div>
                    <div class="mt-30 mb-5">
                        <a class="button medium gray" href="3">IN WINKELMAND</a>
                    </div>

                </div>

            </div>

            <h3 class="abo-subtitel"><span class="abo-subtitel-nummer">5</span>dank je wel!
            </h3>

            <!-- end nr 4 -->


            <!-- SHOP INFO 1 -->
            <div class="shop-info">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 text-center">
                            <a href="../index.html#bestelvw" class="badge badge-light">Min
                                bestelhoeveelheid
                                4x250 gr</a>
                        </div>
                        <div class="col-md-3 col-sm-6 text-center">
                            <a href="../index.html#bestelvw" class="badge badge-light">Levering: 2-3
                                dagen</a>
                        </div>
                        <div class="col-md-3 col-sm-6 text-center">
                            <a href="../index.html#bestelvw" class="badge badge-light">Gratis levering
                                vanaf
                                €70</a>
                        </div>
                        <div class="col-md-3 col-sm-6 text-center">
                            <a href="../klantenservice/klantenservice.html" class="badge badge-light text-left">Klantenservice | Privacy Policy | Alg Voorw</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>

    <?php wp_footer();?>
</body>

</html>