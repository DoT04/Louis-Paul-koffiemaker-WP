<?php

/*
            Template Name: Bestel Page

*/



?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Louis Paul koffiemaker</title>
    <?php wp_head(); ?>
</head>

<body>
    <!-- /main nav -->

    <a href="#menu" class="menu">
        <span class="fa fa-reorder"></span>
    </a>
    <!-- <img src="images/logo2.png" alt="" class="logo"> -->

    <nav class="mainnav" role="mainnav">
        <ul class="links list-unstyled">
            <li><a href="../index.html">Home</a></li>
            <li><a href="../bestel/bestel.html#proefpakket">Proefpakket</a></li>
            <li><a href="../abonnement/abonnement.html#abonnement">Koffieabonnement</a></li>
            <li><a href="../bestel/bestel.html#single-origin">Koffiebonen SINGLE ORIGIN</a></li>
            <li><a href="../overons/overons.html">Over ons</a></li>
            <li><a href="../klantenservice/klantenservice.html" title="">Klantenservice</a></li>
        </ul>
    </nav>

 <header>
 <div class="overons-titel-cont overons-titel-img" style="background-image: url(../images/img9.jpg)">
        <div class="relative container">
            <div class="row">

                <div class="col-md-8 wow animate__animated animate__fadeInDownBig" data-wow-duration="1500ms"
                    data-wow-delay="100ms" id="proefpakket">
                    <h1 class="overons-titel">PROEFPAKKET BESTELLEN</h1>
                    <div class="overons-subtitel">
                        unieke smaken, unieke koffiebonen voor een uitzonderlijke koffie
                    </div>
                </div>


            </div>
        </div>
    </div>
 </header>

    <!-- BESTEL PROEFPAKKET   EN ABONNEMENT-->
    <div class="container">
        <div class="lege-ruimte"></div>
        <div class="row mb-50 prijstabel-cont">


            <div class="col-md-4 mb-30 prijstabel prijstabel-proefpakket mb-5">
                <div class="pricing-table-4 ">
                    <h1 class="pt-h4-container">PROEFPAKKET</h1>
                    <div class="card-prijs mb-5">
                        <span class="card-euro">€ <del>&euro;35.20</del>
                        </span><span class="card-bedrag">&euro;34</span>
                        <!-- <span class="card-maand">
                                <span class="place2-4">/&nbsp;maand</span>
                            </span> -->
                    </div>


                    <ul class="pt4-ul">
                        <li><strong>4</strong> Single Origins</li>
                        <li><strong>4</strong> x 250 gr</li>
                        <li><strong>4</strong> Unieke bonen</li>
                        <li><strong>4</strong> Unieke smaken</li>
                        <li><strong>4</strong> Smaakkprofielen</li>
                        <li><strong>4</strong> Topkoffies</li>
                        <br>
                        <li><strong>Kies</strong> Bonen of gemalen</li>
                    </ul>


                </div>
            </div>

            <!-- CONTENT -->
            <div class="col-md-6 col-sm-12 col-md-offset-1 mb-5 bestel-cont2">


                <div class="row">

                    <div class="col-xs-6  mt-0 mb-30">
                        <del>&euro;35.20</del>
                        <strong class="item-price">&euro;34</strong>
                    </div>



                </div>

                <hr class="mt-0 mb-30">

                <div class="mb-30">
                    Proef onze heerlijke <span class="bold">4 verse Single Origin koffies</span> in dit pakket: <br><br>
                    1x 250 gr Guatemala El Zapote <br> 1x 250 gr Costa Rica Tarrazu <br> 1x 250 gr Peru El Palto <br> 1x
                    250 gr Colombia Finca Santafe <br><br>
                    Ontdek 4 unieke smaakprofielen van koffies van over heel de wereld. Een perfecte manier om onze
                    selectie te ontdekken. <br> Of geef je dit overheerlijk pakket liever cadeau?
                </div>



                <div class="row">
                    <div class="col-sm-6 mb-30">
                        <form method="post" action="#" class="form">
                            <select class="select-md input-border w-100">
                                <option>Gewicht</option>
                                <option>4 x250 gr</option>
                                <!-- <option>1 kg</option> -->

                            </select>
                        </form>
                    </div>

                    <div class="col-sm-6 mb-30">
                        <form method="post" action="#" class="form">
                            <select class="select-md input-border w-100">
                                <option>Maling</option>
                                <option>Bonen</option>
                                <option>Maling: espresso</option>
                                <option>Maling: snelfilter</option>
                            </select>
                        </form>
                    </div>
                </div>



                <!-- ADD TO CART -->
                <div class="row">

                    <div class="col-xs-4 col-sm-2 col-md-2  mb-30">
                        <form method="post" action="#" class="form"></form>
                        <input type="number" class="input-border" min="1" max="100" value="1">
                    </div>
                    <div class="col-xs-8 col-sm-10 col-md-6 mb-30">
                        <div class="post-prev-more-cont clearfix">
                            <div class="shop-add-btn-cont">
                                <a class="button medium gray shop-add-btn" href="#">IN WINKELMAND</a>
                            </div>

                        </div>
                    </div>

                </div>





            </div>


        </div>
    </div>




    <div id="wrap">



        <div class="overons-titel-cont overons-titel-img" style="background-image: url(../images/img9.jpg)">
            <div class="relative container">
                <div class="row">

                    <div class="col-md-8  wow animate__animated animate__fadeInDownBig" data-wow-duration="1500ms"
                        data-wow-delay="100ms" id="single-origin">
                        <h1 class="overons-titel">SINGLE ORIGIN BESTELLEN</h1>
                        <div class="overons-subtitel">
                            unieke smaken, unieke koffiebonen voor een uitzonderlijke koffie
                        </div>
                    </div>


                </div>
            </div>
        </div>

        <!-- CONTENT -->
        <div class="page-section pt-5">
            <div class="container">

                <div class="row">

                    <!-- ITEM PHOTO 1 -->
                    <div class="col-md-4 col-sm-12 mb-50">

                        <div class="bestel-img">
                            <img src="../images/img1.jpg" alt="img" width="370" height="470">
                        </div>
                        <!--  <div class="sale-label-cont">
              <span class="sale-label label-danger bg-red">SALE</span>
            </div>   -->

                    </div>

                    <!-- CONTENT -->
                    <div class="col-md-7 col-sm-12 col-md-offset-1 mb-5 bestel-cont2" id="single-origin1">

                        <h3 class="mt-0 mb-30 bold">GUATEMALA EL ZAPOTE</h3>

                        <hr class="mt-0 mb-30">
                        <div class="row">

                            <div class="col-xs-6  mt-0 mb-30">
                                <!-- <del>$130.00</del> -->
                                <strong class="item-price">&euro;8.80</strong>
                            </div>



                        </div>

                        <hr class="mt-0 mb-30">

                        <div class="mb-30">
                            Finca El Zapote is een bijzondere koffie met een traditioneel karakter. Een zoete koffie met
                            tonen van karamel en hazelnoot en met een licht sprankelende frisheid. Met een volle, zoete
                            en romige afdronk is dit de ideale koffie om de hele dag door te drinken. Heerlijk als
                            espresso en lungo maar ook geschikt als filterkoffie.
                        </div>



                        <div class="row">
                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Gewicht</option>
                                        <option>250 gr</option>
                                        <!-- <option>1 kg</option> -->

                                    </select>
                                </form>
                            </div>

                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Maling</option>
                                        <option>Bonen</option>
                                        <option>Maling: espresso</option>
                                        <option>Maling: snelfilter</option>
                                    </select>
                                </form>
                            </div>
                        </div>



                        <!-- ADD TO CART 1-->
                        <div class="row">

                            <div class="col-xs-4 col-sm-2 col-md-2  mb-30">
                                <form method="post" action="#" class="form"></form>
                                <input type="number" class="input-border" min="1" max="100" value="1">
                            </div>
                            <div class="col-xs-8 col-sm-10 col-md-6 mb-30">
                                <div class="post-prev-more-cont clearfix">
                                    <div class="shop-add-btn-cont">
                                        <a class="button medium gray shop-add-btn" href="#">IN WINKELMAND</a>
                                    </div>

                                </div>
                            </div>

                        </div>





                    </div>

                </div>


                <hr class="mt-0 mb-30">




            </div>
        </div>

        <!-- CONTENT -->
        <div class="page-section pt-5">
            <div class="container">
                <div class="row">

                    <!-- ITEM PHOTO 2-->
                    <div class="col-md-4 col-sm-12 mb-50">

                        <div class="bestel-img">
                            <img src="../images/img2.jpg" alt="img" width="370" height="470">
                        </div>
                        <!--  <div class="sale-label-cont">
              <span class="sale-label label-danger bg-red">SALE</span>
            </div>   -->

                    </div>

                    <!-- CONTENT 2-->
                    <div class="col-md-7 col-sm-12 col-md-offset-1 mb-5 bestel-cont2" id="single-origin2">

                        <h3 class="mt-0 mb-30 bold">COSTA RICA TARRAZU</h3>

                        <hr class="mt-0 mb-30">
                        <div class="row">

                            <div class="col-xs-6  mt-0 mb-30">
                                <!-- <del>$130.00</del> -->
                                <strong class="item-price">&euro;8.80</strong>
                            </div>



                        </div>

                        <hr class="mt-0 mb-30">

                        <div class="mb-30">
                            De Costa Rica Tarrazu is een milde, zoete, gebalanceerde koffie met tonen van noten en
                            chocolade. Een heerlijke, plezierige koffie om de hele dag door te drinken. Heerlijk als
                            espresso, maar ook prima geschikt voor filterkoffie.
                        </div>



                        <div class="row">
                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Gewicht</option>
                                        <option>250 gr</option>
                                        <!-- <option>1 kg</option> -->

                                    </select>
                                </form>
                            </div>

                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Maling</option>
                                        <option>Bonen</option>
                                        <option>Maling: espresso</option>
                                        <option>Maling: snelfilter</option>
                                    </select>
                                </form>
                            </div>
                        </div>



                        <!-- ADD TO CART 2-->
                        <div class="row">

                            <div class="col-xs-4 col-sm-2 col-md-2  mb-30">
                                <form method="post" action="#" class="form"></form>
                                <input type="number" class="input-border" min="1" max="100" value="1">
                            </div>
                            <div class="col-xs-8 col-sm-10 col-md-6 mb-30">
                                <div class="post-prev-more-cont clearfix">
                                    <div class="shop-add-btn-cont">
                                        <a class="button medium gray shop-add-btn" href="#">IN WINKELMAND</a>
                                    </div>

                                </div>
                            </div>

                        </div>





                    </div>

                </div>


                <hr class="mt-0 mb-30">




            </div>
        </div>

        <!-- CONTENT -->
        <div class="page-section pt-5">
            <div class="container">
                <div class="row">

                    <!-- ITEM PHOTO 3-->
                    <div class="col-md-4 col-sm-12 mb-50">

                        <div class="bestel-img">
                            <img src="../images/img1.jpg" alt="img" width="370" height="470">
                        </div>
                        <!--  <div class="sale-label-cont">
              <span class="sale-label label-danger bg-red">SALE</span>
            </div>   -->

                    </div>

                    <!-- CONTENT 3-->
                    <div class="col-md-7 col-sm-12 col-md-offset-1 mb-5 bestel-cont2" id="single-origin3">

                        <h3 class="mt-0 mb-30 bold">PERU EL PALTO</h3>

                        <hr class="mt-0 mb-30">
                        <div class="row">

                            <div class="col-xs-6  mt-0 mb-30">
                                <!-- <del>&euro;130.00</del> -->
                                <strong class="item-price">&euro;8.80</strong>
                            </div>



                        </div>

                        <hr class="mt-0 mb-30">

                        <div class="mb-30">
                            De Peru El Palto is een heerlijke, zachte, romige, zoete koffie met tonen van melkchocolade,
                            toffee en geroosterde pecannoten. Door zijn lage zuurgraad is deze koffie ideaal geschikt
                            voor lungo, espresso en als basis voor een cappuccino. Deze koffie kun je de hele dag door
                            blijven drinken.
                        </div>



                        <div class="row">
                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Gewicht</option>
                                        <option>250 gr</option>
                                        <!-- <option>1 kg</option> -->

                                    </select>
                                </form>
                            </div>

                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Maling</option>
                                        <option>Bonen</option>
                                        <option>Maling: espresso</option>
                                        <option>Maling: snelfilter</option>
                                    </select>
                                </form>
                            </div>
                        </div>



                        <!-- ADD TO CART 3-->
                        <div class="row">

                            <div class="col-xs-4 col-sm-2 col-md-2  mb-30">
                                <form method="post" action="#" class="form"></form>
                                <input type="number" class="input-border" min="1" max="100" value="1">
                            </div>
                            <div class="col-xs-8 col-sm-10 col-md-6 mb-30">
                                <div class="post-prev-more-cont clearfix">
                                    <div class="shop-add-btn-cont">
                                        <a class="button medium gray shop-add-btn" href="#">IN WINKELMAND</a>
                                    </div>

                                </div>
                            </div>

                        </div>





                    </div>

                </div>

                <hr class="mt-0 mb-30">



                <!-- ITEM PHOTO 4 -->

            </div>
        </div>

        <!-- CONTENT -->
        <div class="page-section pt-5">
            <div class="container">

                <div class="row">

                    <!-- ITEM PHOTO 4-->
                    <div class="col-md-4 col-sm-12 mb-50">

                        <div class="bestel-img">
                            <img src="../images/img2.jpg" alt="img" width="370" height="470" id="single-origin4">
                        </div>
                        <!--  <div class="sale-label-cont">
              <span class="sale-label label-danger bg-red">SALE</span>
            </div>   -->

                    </div>

                    <!-- CONTENT 4-->
                    <div class="col-md-7 col-sm-12 col-md-offset-1 mb-5 bestel-cont2">

                        <h3 class="mt-0 mb-30 bold">COLOMBIA FINCA SANTAFE</h3>

                        <hr class="mt-0 mb-30">
                        <div class="row">

                            <div class="col-xs-6  mt-0 mb-30">
                                <!-- <del>$130.00</del> -->
                                <strong class="item-price">&euro;8.80</strong>
                            </div>



                        </div>

                        <hr class="mt-0 mb-30">

                        <div class="mb-30">
                            Deze Direct Trade koffie is complex en veelzijdig. Een heerlijke, romige, stevige koffie met
                            een volle body met tonen van pure chocolade, karamel en zoete kersen. Een koffie met een
                            zoete afdronk en een vol mondgevoel. Absoluut een topper!
                        </div>



                        <div class="row">
                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Gewicht</option>
                                        <option>250 gr</option>
                                        <!-- <option>1 kg</option> -->

                                    </select>
                                </form>
                            </div>

                            <div class="col-sm-6 mb-30">
                                <form method="post" action="#" class="form">
                                    <select class="select-md input-border w-100">
                                        <option>Maling</option>
                                        <option>Bonen</option>
                                        <option>Maling: espresso</option>
                                        <option>Maling: snelfilter</option>
                                    </select>
                                </form>
                            </div>
                        </div>



                        <!-- ADD TO CART 4-->
                        <div class="row">

                            <div class="col-xs-4 col-sm-2 col-md-2  mb-30">
                                <form method="post" action="#" class="form"></form>
                                <input type="number" class="input-border" min="1" max="100" value="1">
                            </div>
                            <div class="col-xs-8 col-sm-10 col-md-6 mb-30">
                                <div class="post-prev-more-cont clearfix">
                                    <div class="shop-add-btn-cont">
                                        <a class="button medium gray shop-add-btn" href="#">IN WINKELMAND</a>
                                    </div>

                                </div>
                            </div>

                        </div>





                    </div>

                </div>
            </div>



            <hr class="mt-0 mb-80">


        </div>

        <!-- SHOP INFO 1 -->
        <div class="shop-info">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6 text-center">
                        <a href="../index.html#bestelvw" class="badge badge-light">Min bestelhoeveelheid
                            4x250 gr</a>
                    </div>
                    <div class="col-md-3 col-sm-6 text-center">
                        <a href="../index.html#bestelvw" class="badge badge-light">Levering: 2-3
                            dagen</a>
                    </div>
                    <div class="col-md-3 col-sm-6 text-center">
                        <a href="../index.html#bestelvw" class="badge badge-light">Gratis levering vanaf
                            €70</a>
                    </div>
                    <div class="col-md-3 col-sm-6 text-center">
                        <a href="../klantenservice/klantenservice.html"
                            class="badge badge-light text-left">Klantenservice | Privacy Policy | Alg Voorw</a>
                    </div>
                </div>
            </div>
        </div>








    </div><!-- End wrap -->

    <?php wp_footer();?>
</body>

</html>