<?php
function load_scripts(){
    //CS inladen

    wp_enqueue_style('bootstrap-min','https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css');
    wp_enqueue_style('opmaak',get_template_directory_uri().'/css/opmaak.css');
    wp_enqueue_style('reset',get_template_directory_uri().'/css/reset.css');
    wp_enqueue_style('animate',get_template_directory_uri().'/css/animate.min.css');
    wp_enqueue_style('animate-min','https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css');

    //JS inladen



wp_enqueue_script('jquery-bib','https://code.jquery.com/jquery-3.2.1.min.js',array(),'3.2.1',true);
wp_enqueue_script('main',get_template_directory_uri().'/js/main.js',array(),'1.1',true);
wp_enqueue_script('popper','https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js',array(),'1.16.0',true);
wp_enqueue_script('bootstrap-min','https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js',array(),'4.5.0',true);

wp_enqueue_script('main-min',get_template_directory_uri().'/js/main.min.js',array(),'null',true);
wp_enqueue_script('parallax','https://cdn.jsdelivr.net/parallax.js/1.4.2/parallax.min.js',array(),'1.4.2',true);
wp_enqueue_script('wow','https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js',array(),'1.16.0',true);
wp_enqueue_script('wow-min',get_template_directory_uri().'/js/wow.min.js',array(),'null',true);
wp_enqueue_script('fontawesome','https://kit.fontawesome.com/95a39aa43a.js',array(),'1.1',true);
}


add_action('wp_enqueue_scripts','load_scripts');


// Sidebars

add_action('widgets_init', 'lpkm_sidebars');
function lpkm_sidebars(){
    register_sidebar(
array(
    'name' => 'Titeltekst',
    'id' => 'titel',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );

    register_sidebar(
array(
    'name' => 'Bestelformules',
    'id' => 'bestelformules',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );
    register_sidebar(
array(
    'name' => 'Bestelformules-proefpakket',
    'id' => 'bestelformules-proefpakket',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );
    register_sidebar(
array(
    'name' => 'Bestelformules-abonnement',
    'id' => 'bestelformules-abonnement',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );
  
    register_sidebar(
array(
    'name' => 'Faq-proefpakket',
    'id' => 'faq-proefpakket',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );
    register_sidebar(
array(
            'name' => 'Faq-abonnement',
            'id' => 'faq-abonnement',
            'description' => 'Typ hier je tekst ...',
            'before_widget' => '<div class="widget-wrapper">',
            'after_widget' => '</div>',
            'before_title' => '<div class="widget-title">',
            'after_title' => '</div>'
            )
            );
    register_sidebar(
        array(
    'name' => 'Faq-singleorigin',
    'id' => 'faq-singleorigin',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );
    register_sidebar(
array(
    'name' => 'Faq-bestelvoorwaarden',
    'id' => 'faq-bestelvoorwaarden',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );


    register_sidebar(
array(
    'name' => 'Troeven-slowroasting',
    'id' => 'troeven-slowroasting',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );
    register_sidebar(
array(
    'name' => 'Troeven-verzending',
    'id' => 'troeven-verzending',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );
    register_sidebar(
array(
    'name' => 'Troeven-specialty',
    'id' => 'troeven-specialty',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );
    register_sidebar(
array(
            'name' => 'Troeven-eerlijk',
            'id' => 'troeven-eerlijk',
            'description' => 'Typ hier je tekst ...',
            'before_widget' => '<div class="widget-wrapper">',
            'after_widget' => '</div>',
            'before_title' => '<div class="widget-title">',
            'after_title' => '</div>'
            )
            );
    register_sidebar(
array(
            'name' => 'Troeven-singleorigin',
            'id' => 'troeven-singleorigin',
            'description' => 'Typ hier je tekst ...',
            'before_widget' => '<div class="widget-wrapper">',
            'after_widget' => '</div>',
            'before_title' => '<div class="widget-title">',
            'after_title' => '</div>'
            )
            );


    register_sidebar(
array(
    'name' => 'Parallax',
    'id' => 'parallax',
    'description' => 'Typ hier je tekst ...',
    'before_widget' => '<div class="widget-wrapper">',
    'after_widget' => '</div>',
    'before_title' => '<div class="widget-title">',
    'after_title' => '</div>'
    )
    );


}

//* Enqueue Animate.CSS and WOW.js
add_action( 'wp_enqueue_scripts', 'sk_enqueue_scripts' );
function sk_enqueue_scripts() {

	wp_enqueue_style( 'animate', get_stylesheet_directory_uri() . '/css/animate.min.css' );

	wp_enqueue_script( 'wow', get_stylesheet_directory_uri() . '/js/wow.min.js', array(), '', true );

}
//Functionaliteiten dashboard toevoegen

add_theme_support('post-thumbnails');
add_theme_support('custom-logo');

//menu's

register_nav_menus(
    array(
    'primary' => 'Hoofdmenu',
    // 'privacy' => 'Privacymenu'
        )
    );


 





//* Enqueue script to activate WOW.js
add_action('wp_enqueue_scripts', 'sk_wow_init_in_footer');
function sk_wow_init_in_footer() {
	add_action( 'print_footer_scripts', 'wow_init' );
}



//* Add JavaScript before </body>
function wow_init() { ?>
	<script type="text/javascript">
		new WOW().init();
	</script>
<?php }





?>