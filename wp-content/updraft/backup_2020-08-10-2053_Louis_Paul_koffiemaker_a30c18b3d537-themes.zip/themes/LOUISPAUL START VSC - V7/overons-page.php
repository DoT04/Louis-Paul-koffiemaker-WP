<?php

/*
            Template Name: Over ons Page

*/



?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Louis Paul koffiemaker</title>
    <?php wp_head(); ?>
</head>

<body>
    <!-- /main nav -->

    <a href="#menu" class="menu">
        <span class="fa fa-reorder"></span>
    </a>
    <!-- <img src="images/logo2.png" alt="" class="logo"> -->

    <nav class="mainnav" role="mainnav">
        <ul class="links list-unstyled">
            <li><a href="../index.html">Home</a></li>
            <li><a href="../bestel/bestel.html#proefpakket">Proefpakket</a></li>
            <li><a href="../abonnement/abonnement.html#abonnement">Koffieabonnement</a></li>
            <li><a href="../bestel/bestel.html#single-origin">Koffiebonen SINGLE ORIGIN</a></li>
            <li><a href="../overons/overons.html">Over ons</a></li>
            <li><a href="../klantenservice/klantenservice.html" title="">Klantenservice</a></li>
        </ul>
    </nav>

   <header>
   <div class="overons-titel-cont overons-titel-img" style="background-image: url(../images/img9.jpg)">
        <div class="relative container">
            <div class="row">

                <div class="col-md-8">
                    <h1 class="overons-titel">OVER ONS</h1>
                    <div class="overons-subtitel">
                        unieke smaken, unieke koffiebonen voor een uitzonderlijke koffie
                    </div>
                </div>


            </div>
        </div>
    </div>
   </header>

    <!-- ABOUT US 1 -->
    <div class="page-section overons-cont" id="overons">
        <div class="container">
            <div class="row">

                <div class="overons-cont1 col-md-3 col-sm-3 wow animate__animated animate__fadeInUp">
                    <div class="overons-image">
                        <a href="../bestel/bestel.html"> <img class="mx-auto d-block" src="../images/koffiebes.jpg"
                                alt="img" width="180" height="180"></a>
                    </div>
                    <h3>DIRECT TRADE</h3>
                    <span>eerlijke inkoop</span>
                    <div class="overons-cont2">
                        <br>
                        <p>Direct Trade koffiesoorten rechtstreeks ingekocht, zonder tussenhandel, bij de boer.</p>
                    </div>

                </div>

                <div class="overons-cont1 col-md-3 col-sm-3 wow animate__animated animate__fadeInUp"
                    data-wow-delay="200ms">
                    <div class="overons-image">
                        <a href="..bestel/bestel.html"><img class="mx-auto d-block" src="../images/arabica.jpg"
                                alt="img" width="180" height="180"></a>
                        <h3>SINGLE ORIGIN</h3>
                        <span>100% Arabica</span>
                        <div class="overons-cont2">
                            <br>
                            <p>Koffiebonen die niet gemengd worden met een andere soort. Afkomstig van een bepaald
                                gebied of bepaalde plantage.</p>
                        </div>
                    </div>



                </div>

                <div class="overons-cont1 col-md-3 col-sm-3 wow animate__animated animate__fadeInUp"
                    data-wow-delay="200ms">
                    <div class="overons-image">
                        <a href="../bestel/bestel.html"><img class="mx-auto d-block" src="../images/koffieboon.jpg"
                                alt="img" width="180" height="180"></a>
                        <h3>SPECIALITY COFFEE</h3>
                        <span>uniek aroma</span>
                        <div class="overons-cont2">
                            <br>
                            <p>Een kleine selectie sterk aromatische koffiebonen gegroeid in perfecte
                                weersomstandigheden. Elke koffie krijgt zijn eigen brandprofiel.</p>
                        </div>
                    </div>



                </div>
                <div class="overons-cont1 col-md-3 col-sm-3 wow animate__animated animate__fadeInUp"
                    data-wow-delay="200ms">
                    <div class="overons-image">
                        <a href="../bestel/bestel.html"><img class="mx-auto d-block" src="../images/koffiebrander.jpg"
                                alt="img" width="180" height="180"></a>
                        <h3>SLOW ROASTING</h3>
                        <span>ambachtelijk geroosterd</span>
                        <div class="overons-cont2">
                            <br>
                            <p>Ambachtelijk extra langzaam geroosterde koffiebonen voor een rijke, pure smaak.</p>
                        </div>
                    </div>



                </div>

            </div>
        </div>

        <!-- SHOP INFO 1 -->
        <div class="shop-info">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6 text-center">
                        <a href="../index.html#bestelvw" class="badge badge-light">Min bestelhoeveelheid
                            4x250 gr</a>
                    </div>
                    <div class="col-md-3 col-sm-6 text-center">
                        <a href="../index.html#bestelvw" class="badge badge-light">Levering: 2-3
                            dagen</a>
                    </div>
                    <div class="col-md-3 col-sm-6 text-center">
                        <a href="../index.html#bestelvw" class="badge badge-light">Gratis levering vanaf
                            €70</a>
                    </div>
                    <div class="col-md-3 col-sm-6 text-center">
                        <a href="../klantenservice/klantenservice.html" class="badge badge-light text-left">Klantenservice | Privacy Policy | Alg Voorw</a>
                    </div>
                </div>
            </div>
        </div>

    </div>





   


<?php wp_footer();?>

</body>

</html>