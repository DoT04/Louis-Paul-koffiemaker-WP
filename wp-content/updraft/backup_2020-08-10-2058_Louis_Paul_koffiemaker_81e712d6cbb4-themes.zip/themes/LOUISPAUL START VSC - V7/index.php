<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Louis Paul koffiemaker</title>
   <!--  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link href="css/opmaak.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
 -->
 <?php wp_head(); ?>
</head>

<body id="home">
    

    <!-- /main nav -->

    <a href="#menu" class="menu">
        <span class="fa fa-reorder"></span>
    </a>
    <!-- <img src="images/logo2.png" alt="" class="logo"> -->

    <nav class="mainnav" role="mainnav">

    <?php 
        wp_nav_menu(
            array(
                'theme_location' => 'primary',
                'menu_class' => 'links'
            )
        )
        ?>  

        <!-- <ul class="links list-unstyled">
            <li><a href="#home">Home</a></li>
            <li><a href="../bestel/bestel.html#proefpakket">Proefpakket</a></li>
            <li><a href="../abonnement/abonnement.html#abonnement">Koffieabonnement</a></li>
            <li><a href="../bestel/bestel.html#single-origin">Koffiebonen SINGLE ORIGIN</a></li>
            <li><a href="../overons/overons.html">Over ons</a></li>
            <li><a href="../klantenservice/klantenservice.html" title="">Klantenservice</a></li>
        </ul> -->
    </nav>

    <!-- mainheader -->
    <header class="mainheader parallax-window" data-parallax="scroll" data-image-src="images/hero1.jpg">

        <div class="overlay">

        <?php 
                if(is_active_sidebar('titel')){
                    dynamic_sidebar('titel');
                }
                ?>
            <!-- <blockquote>

                <p class="blockquote"><q>"De smaakervaring <br>van deze bonen is apart.<br>Perfect voor
                        koffieliefhebbers."</q></p>
            </blockquote> -->
            <div class="con">
                <div class="row">
                    <div class="col-md-6 pr-0">
                        <div class="mt-30">
                            <a class="button-quote" href="bestel/bestel.html">MEER WETEN?</a>
                        </div>

                    </div>
                    <div class="col-md-6 pl-0">
                        <div class="mt-30">
                            <a class="button-quote" href="abonnement/abonnement.html">KOFFIEABONNEMENT</a>
                        </div>
                    </div>
                </div>
            </div>
            <!--   <h1>Louis Paul</h1>
            <p class="overlay-titel">koffiemaker</p>  -->

        </div>
        <!--overlay-->
        <a href="#home-icons" class="downbutton"><span class="fa fa-chevron-down"></span></a>
    </header>

    <!-- main -->


    <!--HOME ICON SECTION  -->
    <section id="home-icons" class="py-5">
        <div class="container">
       
            <div class="row">
        
                <div class="col-md-3 icon wow animate__animated animate__fadeInLeftBig" data-wow-duration="2s">
                    <a href="bestel/bestel.html" class="center">
                    <i class="fal fa-mug-hot"></i></a>
              
                    <h3 class="icontitel">Koffie</h3>
                    <p class="iconcont">Elke koffie met een perfect evenwicht.
                        <br><span class="bold">SINGLE ORIGIN</span></p>
                </div>

                <div class="col-md-3 icon wow animate__animated animate__fadeInLeftBig" data-wow-duration="2s"
                    data-wow-delay="200Ms">
                    <a href="bestel/bestel.html" class="center"><i class="fal fa-check-square"></i></a>
                    <h3 class="icontitel">Smaak</h3>
                    <p class="iconcont">Elke koffie met een eigen smaakprofiel.
                        <br><span class="bold">UNIEKE SMAKEN</span></p>
                </div>
                <div class="col-md-3 icon wow animate__animated animate__fadeInLeftBig" data-wow-duration="2s"
                    data-wow-delay="400Ms">
                    <a href="bestel/bestel.html" class="center"><i class="fal fa-plus-square"></i></a>
                    <h3 class="icontitel">Karakter</h3>
                    <p class="iconcont">Heerlijke aroma's, volle body, aangename nasmaak.
                        <br><span class="bold">UNIEKE BONEN</span></p>
                </div>
                <div class="col-md-3 icon wow animate__animated animate__fadeInLeftBig" data-wow-duration="2s"
                    data-wow-delay="600ms">

                    <a href="bestel/bestel.html" class="center"><i class="fal fa-shopping-bag"></i></a>
                    <h3 class="icontitel">Bestellen</h3>
                    <p class="iconcont">Levering steeds vers gebrand binnen 2-3 dagen.
                        <br><span class="bold">VERSHEIDSGARANTIE</span></p>

                </div>
            </div>
        </div>
    </section>

  

    <!-- INFO SECTION BESTELFORMULES-->
    <section id="info" class="py-5 mb-80">

        <div class="container">

            <div class="row">
                <div class="col-md-9 col-sm-12 align-self-center">
                <?php 
                if(is_active_sidebar('bestelformules')){
                    dynamic_sidebar('bestelformules');
                }
                ?>
                
                    <!-- <h3 class="info-titel2 mb-30">LOUIS PAUL KOFFIEMAKER</h3> -->
                    <!-- <p class="info-cont my-3">Unieke smaken, unieke koffiebonen speciaal voor jou geselecteerd voor een
                        uitzonderlijke koffie. <br>Laat je eenvoudig verrassen door onze gemakkelijke <a
                            href="../bestel/bestel.html" class="info-link"><strong>bestelformules</strong></a>.</p> -->
                    <a href="../overons/overons.html" class="button-quote mt-3 mb-3">Meer weten?</a>
                </div>
                <div class="col-md-3 col-sm-12">
                    <img src="images/koffiebes.jpg" alt="" class="img-fluid">
                </div>
            </div>
        </div>
    </section>

    <!-- START ADS  PROEFPAKKET EN ABONNEMENT-->
    <div class="page-section">
        <div class="container">
            <div class="row">

                <!-- class="row ad" -->




                <div class="col-md-6 left-50 pr-0 mr-0 pl-5">

                    <div class="ads-img-cont wow animate__animated animate__fadeInLeft">
                        <img src="images/img1v.jpg" alt="img" class="img-fluid" width="555" height="447">
                    </div>

                </div>

                <div class="col-md-6 right-50" id="proefpakket">
                    <div class="text-cont-right">
                        <div class="title-ad">
                            <span class="logonaam">Louis Paul</span> KOFFIEBONEN<br>
                            <span class="bold">PROEFPAKKET</span>
                        </div>
                        <div class="lijn"></div>
                        <?php 
                if(is_active_sidebar('bestelformules-proefpakket')){
                    dynamic_sidebar('bestelformules-proefpakket');
                }
                ?>
                        <!-- <div class="text-cont">Single Origin koffiebonen. Proefpakket 4 x 250 gr overheerlijke koffie
                            tegen een aantrekkelijke prijs. Heerlijk om de smaak van echt verse <br>Single Origins te
                            ontdekken. <br>Of geef dit proefpakket cadeau?</div> -->
                        <div class="mt-30">
                            <a class="button medium thin hover-dark" href="bestel/bestel.html">MEER WETEN?</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 left-50" id="abonnement">
                    <div class="text-cont-left">
                        <div class="title-ad">
                            <span class="logonaam">Louis Paul</span> KOFFIEBONEN<br>
                            <span class="bold">ABONNEMENT</span>
                        </div>
                        <div class="lijn"></div>
                        <?php 
                if(is_active_sidebar('bestelformules-abonnement')){
                    dynamic_sidebar('bestelformules-abonnement');
                }
                ?>
                        <!-- <div class="text-cont">Kies je eigen formule: <br>voortdurend abonnement of liever een formule
                            voor 3 of 6 maand? Aan jou de keuze.</div> -->
                        <div class="mt-30">
                            <a class="button medium thin hover-dark" href="abonnement/abonnement.html">MEER WETEN?</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 right-50">

                    <div class="ads-img-cont wow animate__animated animate__fadeInRight">
                        <img src="images/img2v.jpg" alt="img" class="img-fluid" width="555" height="447">
                    </div>

                </div>

            </div>
        </div>
    </div>

    <!-- EINDE ADS  PROEFPAKKET EN ABONNEMENT-->

    <!-- START SHOP ITEMS BESTSELLERS-->
    <page-section class="shop-page" id="bestsellers">
        <div class="container">


            <div class="bestsellertitel" id="single-origin">
                <h2 class="bestseller-titel">BEST SELLERS <span class="bold">SINGLE ORIGIN</span>
                </h2>
            </div>

            <div class="row">
            <?php
                    $args = array(
                    'post_type' => 'bestsellers');

                     $bestseller = new WP_Query($args);

                if($bestseller->have_posts()) :
                    while($bestseller->have_posts()) : $bestseller->the_post();
                    ?>
 <div class="col-sm-6 col-md-3 col-lg-3 shopitem1">
                    <div class="col-md-3">
                        <a href="bestel/bestel.html#single-origin1"><img src="<?php the_post_thumbnail_url();?>" width="320" height="410"
                                class="rounded mx-auto d-block" alt="Responsive image"></a>
                    </div>

                  
                    <div class="shopitem-cont">
                        
                        <div class="shopitem-titel mb-2">
                
               
                            <h3><a class="btn shopitem-titel-h3" role="button" href="#single-origin1"><?php the_title();?></a>
                            </h3>
                            <p><?php the_content();?></p>
                        </div>

                        <div class="shopitem-prijs">
                        <?php if(get_field('prijs')):?>
                            <strong><?php the_field('prijs');?></strong>
                        <?php endif;?>
                        </div>

                        <div class="shop-button">
                            <div class="shop-add-btn-cont">
                                <a class="button medium gray-light shop-add-btn"
                                    href="bestel/bestel.html#single-origin1"><?php the_field('meer_weten');?></a>
                            </div>

                        </div>
                    </div>

                </div>
                 


                     <?php
                 endwhile;
                 else: 
                 echo "<p> class='waarschuwing' Er zijn momenteel geen nieuwe bestsellers.</p>";
                 wp_reset_postdata();
                    endif;
                   
                ?>
                <!-- SHOP Item 1 -->
                <!-- <div class="col-sm-6 col-md-3 col-lg-3 shopitem1">
                    <div class="col-md-3">
                        <a href="bestel/bestel.html#single-origin1"><img src="images/img1.jpg" width="310" height="410"
                                class="rounded mx-auto d-block" alt="Responsive image"></a>
                    </div>

                  
                    <div class="shopitem-cont">
                        
                        <div class="shopitem-titel mb-2">
                
               
                            <h3><a class="btn shopitem-titel-h3" role="button" href="#single-origin1">GUATEMALA EL
                                    ZAPOTE</a>
                            </h3>
                            <p>medium roast</p>
                        </div>

                        <div class="shopitem-prijs">
                            <strong>&euro;8.80</strong>
                          
                        </div>

                        <div class="shop-button">
                            <div class="shop-add-btn-cont">
                                <a class="button medium gray-light shop-add-btn"
                                    href="bestel/bestel.html#single-origin1">MEER WETEN?</a>
                            </div>

                        </div>
                    </div>

                </div> -->
                <!-- SHOP Item 2 -->
                <!-- <div class="col-sm-6 col-md-3 col-lg-3 shopitem2">

                    <div class="col-md-3">
                        <a href="bestel/bestel.html#single-origin2"><img src="images/img2.jpg" width="310" height="410"
                                class="rounded mx-auto d-block" alt="Responsive image"></a>
                    </div>
               
                    <div class="shopitem-cont">
                        <div class="shopitem-titel mb-2">
                            <h3><a class="btn shopitem-titel-h3" role="button" href="#single-origin2">COSTA RICA
                                    TARRAZU</a></h3>
                            <p>medium roast</p>
                        </div>

                        <div class="shopitem-prijs">
                            <strong>&euro;8.80</strong>
                        </div>

                        <div class="shop-button">
                            <div class="shop-add-btn-cont">
                                <a class="button medium gray-light shop-add-btn"
                                    href="bestel/bestel.html#single-origin2">MEER WETEN?</a>
                            </div>

                        </div>
                    </div>

                </div> -->
                <!-- SHOP Item 3 -->
                <!-- <div class="col-sm-6 col-md-3 col-lg-3 shopitem3">

                    <div class="col-md-3">
                        <a href="bestel/bestel.html#single-origin3"><img src="images/img1.jpg" width="310" height="410"
                                class="rounded mx-auto d-block" alt="Responsive image"></a>
                    </div>
                 
                    <div class="shopitem-cont">
                        <div class="shopitem-titel mb-2">
                            <h3><a class="btn shopitem-titel-h3" role="button" href="#single-origin3">PERU EL PALTO</a>
                            </h3>
                            <p>medium roast</p>
                        </div>

                        <div class="shopitem-prijs">
                            <strong>&euro;8.80</strong>
                        </div>

                        <div class="shop-button">
                            <div class="shop-add-btn-cont">
                                <a class="button medium gray-light shop-add-btn"
                                    href="bestel/bestel.html#single-origin3">MEER WETEN?</a>
                            </div>

                        </div>
                    </div>

                </div> -->
                <!-- SHOP Item 4 -->
                <!-- <div class="col-sm-6 col-md-3 col-lg-3 shopitem4">
                    <div class="col-md-3">
                        <a href="bestel/bestel.html#single-origin4"><img src="images/img2.jpg" width="310" height="410"
                                class="rounded mx-auto d-block" alt="Responsive image"></a>
                    </div> -->

                    <!--     <div class="sale-label-cont">
                <span class="sale-label label-danger bg-red">SALE</span>
              </div>  -->
                    <!-- <div class="shopitem-cont">
                        <div class="shopitem-titel mb-2">
                            <h3><a class="btn shopitem-titel-h3" role="button" href="#single-origin4">COLOMBIA FINCA
                                    SANTAFE</a></h3>
                            <p>dark roast</p>
                        </div>

                        <div class="shopitem-prijs">
                            <strong>&euro;8.80</strong>
                        </div>

                        <div class="shop-button">
                            <div class="shop-add-btn-cont">
                                <a class="button medium gray-light shop-add-btn"
                                    href="bestel/bestel.html#single-origin4">MEER WETEN?</a>
                            </div>

                        </div>
                    </div> -->

                </div>




            </div>

        </div>
    </page-section>

    <!-- EINDE SHOP ITEMS BESTSELLERS -->

    <!-- DIVIDER -->
    <hr class="mt-0 mb-0">

    <!-- DIVIDER -->
    <hr class="mt-0 mb-0">



    <!-- SART FAQ -->
    <section id="faq" class="faq-section">
        <div class="container">
       
            <h2 class="faq-titel" id="bestelvw">HEB JE <span class="bold">VRAGEN?</span></h2>
            <hr>
            <div class="row">
                <div class="col-md-6 faq-col1">
                    <div id="accordion">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">
                                    <div href="#collapse1" data-toggle="collapse" data-parent="#accordion">
                                        <i class="fal fa-angle-down"></i> WAT ZIT ER IN HET PROEFPAKKET?
                                    </div>
                                </h5>
                            </div>

                            <div id="collapse1" class="collapse">
                            <?php 
                if(is_active_sidebar('faq-proefpakket')){
                    dynamic_sidebar('faq-proefpakket');
                }
                ?>
                                <!-- <div class="card-body">
                                    Een perfecte manier om onze selectie te ontdekken. <br> In het proefpakket zitten
                                    Single Origin koffiebonen: 4 x 250 gr overheerlijke koffie tegen een aantrekkelijke
                                    prijs. <br><br> 1x 250 gr Guatemala El Zapote <br> 1x 250 gr Costa Rica Tarrazu <br>
                                    1x 250 gr Peru El Palto <br> 1x 250 gr Colombia Finca Santafe <br><br>Heerlijk om de
                                    smaak van echt verse Single Origins te ontdekken. <br>
                                    Ontdek 4 unieke smaakprofielen van koffies van over heel de wereld.<br>

                                </div> -->
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">
                                    <div href="#collapse2" data-toggle="collapse" data-parent="#accordion">
                                        <i class="fal fa-angle-down"></i> MEER WETEN OVER HET KOFFIEABONNEMENT?
                                    </div>
                                </h5>
                            </div>

                            <div id="collapse2" class="collapse">
                            <?php 
                if(is_active_sidebar('faq-abonnement')){
                    dynamic_sidebar('faq-abonnement');
                }
                ?>
                                <!-- <div class="card-body">
                                
                                    Eenvoudig en veilig je abonnement-formule kiezen via onze webshop.<br> Je krijgt
                                    elke maand versgebrande Single Origin koffie in je brievenbus. Kies voor 2 x 225 gr
                                    of 4 x 225 gr. <br>
                                    Handig toch deze brievenbuspost? Je hoeft er niet voor thuis te blijven. <br>En,
                                    verzending zit inbegrepen in de prijs.<br> Geen verplichtingen. Je kan je abonnement
                                    aanpassen of opzeggen op ieder moment.
                                </div> -->
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-md-6 faq-col1">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <div href="#collapse3" data-toggle="collapse" data-parent="#accordion">
                                    <i class="fal fa-angle-down"></i> WAT IS EEN SINGLE ORIGIN KOFFIE?
                                </div>
                            </h5>
                        </div>

                        <div id="collapse3" class="collapse">
                        <?php 
                if(is_active_sidebar('faq-singleorigin')){
                    dynamic_sidebar('faq-singleorigin');
                }
                ?>
                            <!-- <div class="card-body">
                                Single origin koffiebonen zijn afkomstig uit een specifieke regio of plantage bevatten unieke smaakeigenschappen. Deze koffiebonen worden niet gemengd met een andere soort.<br>Op een bepaalde plek zijn de ecologische omstandigheden (de voeding in de bodem, neerslag, hoeveelheid zon etc.) uniek voor een specifieke koffiesoort.<br>Zo is elke single origin koffieboon eigenlijk al bijzonder en een smaakontdekking op zich.<br>Er valt dus nog een hoop aan smaak te ontdekken in de wereld van de Single Origin koffiebonen.
                            </div> -->
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <div href="#collapse4" data-toggle="collapse" data-parent="#accordion">
                                    <i class="fal fa-angle-down"></i> BESTELVOORWAARDEN?
                                </div>
                            </h5>
                        </div>

                        <div id="collapse4" class="collapse">
                        <?php 
                if(is_active_sidebar('faq-bestelvoorwaarden')){
                    dynamic_sidebar('faq-bestelvoorwaarden');
                }
                ?>
                            <!-- <div class="card-body">
                                Minimum bestelhoeveelheid 4x250 gr<br>
Levering: 2-3 dagen<br>Bij ons betaal je voor het verzendklaar maken, controleren, transporteren en bezorgen van de bestelling een vaste bijdrage in de verzendkosten: &euro;4.95.<br>
Gratis levering vanaf €70<br><br>Algemene voorwaarden kan je terugvinden op deze pagina: <a
                                    href="../klantenservice/klantenservice.html">KLANTENSERVICE</a>
                            </div> -->
                        </div>
                    </div>



                </div>



            </div>
        </div>
    </section>

    <!-- EIND FAQ -->


<!-- NEWS LETTER -->

<section class="newsletter">
    <div class="container">
        <div class="row">
            <div class="col-sm-12  wow animate__animated animate__fadeInLeftBig" data-wow-duration="2s"
            data-wow-delay="200ms">
                <div class="content">
                    <form>
                        <h2>INSCHRIJVEN OP ONZE NEWSLETTER</h2>
                        <div class="input-group">
                            <input type="email" class="form-control" placeholder="email-adres toevoegen">
                            <span class="input-group-button ">
                                <button class="button" type="submit">SCHRIJF NU IN</button>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- EIND NEWLETTER -->



    <!-- START TROEVEN -->
    <section id="troeven" class="waardensectie">
        <div class="container troeven">
            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-4 mt-5">
                    <div class="waarde wow animate__animated animate__fadeIn" data-wow-duration="2s"
                    data-wow-delay="200ms">
                        <div class="waardetitel troeven">Onze <span class="bold">Troeven</span></div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class=" waarde  text-center text-center wow animate__animated animate__fadeIn" data-wow-duration="2s"
                    data-wow-delay="400ms">
                        <div class="waarde-body troeven">
                            <i class="fal fa-mug-hot"></i>
                 
                            <h3>slow roasting</h3>
                            <?php 
                if(is_active_sidebar('troeven-slowroasting')){
                    dynamic_sidebar('troeven-slowroasting');
                }
                ?>
                            <!-- <p> Ambachtelijk extra langzaam geroosterde koffiebonen voor een rijke, pure smaak.</p> -->
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class=" waarde text-center text-center wow animate__animated animate__fadeIn" data-wow-duration="2s"
                    data-wow-delay="600ms ">
                        <div class="waarde-body troeven">
                            <i class="fal fa-truck"></i>
                            <h3>Verzending</h3>
                            <?php 
                if(is_active_sidebar('troeven-verzending')){
                    dynamic_sidebar('troeven-verzending');
                }
                ?>
                            <!-- <p> Levering binnen 2-3 dagen. Verzendkost: &euro;4.95.<br>Gratis vanaf &euro;70. Minimum bestelhoeveelheid 4x 250 gr. -->
                            </p>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row mb-4">
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class=" waarde text-center text-center wow animate__animated animate__fadeIn" data-wow-duration="2s"
                    data-wow-delay="800ms">
                        <div class="waarde-body troeven">
                            <i class="fal fa-mug-hot"></i>
                            <h3>Specialty coffees</h3>
                            <?php 
                if(is_active_sidebar('troeven-specialty')){
                    dynamic_sidebar('troeven-specialty');
                }
                ?>
                            <!-- <p> Een kleine selectie sterk aromatische koffiebonen gegroeid in perfecte
                                weersomstandigheden. Elke koffie krijgt zijn eigen brandprofiel.</p> -->
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class=" waarde text-center text-center wow animate__animated animate__fadeIn" data-wow-duration="2s"
                    data-wow-delay="1000ms">
                        <div class="waarde-body troeven">
                            <i class="fal fa-seedling"></i>
                            <h3>Eerlijk - Direct Trade</h3>
                            <?php 
                if(is_active_sidebar('troeven-eerlijk')){
                    dynamic_sidebar('troeven-eerlijk');
                }
                ?>
                            <!-- <p> Direct Trade koffiesoorten rechtstreeks ingekocht,zonder tussenhandel, bij de boer.</p> -->
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class=" waarde text-center wow animate__animated animate__fadeIn" data-wow-duration="2s"
                    data-wow-delay="1200ms">
                        <div class="waarde-body troeven">
                            <i class="fal fa-mug-hot"></i>
                            <h3>single origin</h3>
                            <?php 
                if(is_active_sidebar('troeven-singleorigin')){
                    dynamic_sidebar('troeven-singleorigin');
                }
                ?>
                            <!-- <p>100% Arabica-koffiebonen die niet gemengd worden met een andere soort. Afkomstig van een
                                bepaald gebied of bepaalde plantage.</p> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- EIND TROEVEN -->

    <!-- START IMAGE PARALLAX -->
    <section id="parallax-sectie" class="parallax-window" data-parallax="scroll" data-image-src="images/hero1.jpg">
        <div class="parallax-cont">
        <?php 
                if(is_active_sidebar('parallax')){
                    dynamic_sidebar('parallax');
                }
                ?>
            <!-- <p>Koffie met een helder en uitgebalanceerd karakter.</p>
            <h2>LOUIS PAUL <span class="parallax-titel">KOFFIEMAKER</span></h2> -->
        </div>
    </section>
 
<!-- EIND IMAGE PARALLAX -->


    <!-- START CONTACTGEGEVENS -->
    <section class="contact" id="contact-cont">

        <div class="container cont-container">
            <div class="row ml-4 pl-4 mt-4 mb-4">
                <div class="col-md-4 col-sm-6">
                    <div class="contact-cont relative">
                        <div class="contact-icon">
                            <i class="fal fa-envelope"></i>
                        </div>
                        <div class="contact-text">
                            <h3><span class="bold">info</span></h3>
                            <p>info@louispaulkoffiemaker.be</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="contact-cont relative">
                        <div class="contact-icon">
                            <i class="fal fa-envelope"></i>
                        </div>
                        <div class="contact-text">
                            <h3><span class="bold">verkoop</span></h3>
                            <p>sales@louispaulkoffiemaker.be</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="contact-cont relative">
                        <div class="contact-icon">
                            <i class="fal fa-envelope"></i>
                        </div>
                        <div class="contact-text">
                            <h3><span class="bold">naverkoop</span></h3>
                            <p>after-sales@louispaulkoffiemaker.be</p>
                        </div>
                    </div>
                </div>



            </div>
        </div>

    </section>

    <!-- EIND CONTACTGEGEVENS -->



    <!-- START FOOTER -->
    <footer id="footer" class="footer-cont">
        <div class="container footercontainer">

            <!-- Social Links -->
            <div class="row">

                <div class="col footer-soc-a">
                    <a href="#" title="Facebook" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" title="Instagram" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="#" title="LinkedIn" target="_blank"><i class="fab fa-linkedin-in"></i></a>

                </div>

            </div>

            <footer class="mainfooter">
                <div class="container">
                    <a href="../klantenservice/klantenservice.html" target="_blank" class="footer-link"><strong>&copy;
                            Louis Paul koffiemaker, 2020. </strong></a> Alle rechten voorbehouden. | <a
                        href="../klantenservice/klantenservice.html#privacy"
                        title="Link naar de Privacy Policy en  Algemene Voorwaarden van deze website" class="button">Privacy Policy | Voorwaarden</a>
                </div> <!-- container -->
            </footer>



        </div>

    </footer>

<!-- EIND FOOTER -->

    <!-- JQUERY ------------------------------------------------>
  <!--   <script src="https://kit.fontawesome.com/95a39aa43a.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
        integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous">
    </script>

    <script src="js/main.js"></script>

    <script src="https://cdn.jsdelivr.net/parallax.js/1.4.2/parallax.min.js"></script>

    <script src="js/wow.min.js"></script>

    <script>
        new WOW().init();
    </script> -->



     <?php wp_footer();?>
</body>

</html>