<?php

/*
            Template Name: Klantenservice Page

*/



?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Louis Paul koffiemaker</title>
    <?php wp_head(); ?>
</head>

<body>
    <!-- /main nav -->

    <a href="#menu" class="menu">
        <span class="fa fa-reorder"></span>
    </a>
    <!-- <img src="images/logo2.png" alt="" class="logo"> -->

    <nav class="mainnav" role="mainnav">
        <ul class="links list-unstyled">
            <li><a href="../index.html">Home</a></li>
            <li><a href="../bestel/bestel.html#proefpakket">Proefpakket</a></li>
            <li><a href="../abonnement/abonnement.html#abonnement">Koffieabonnement</a></li>
            <li><a href="../bestel/bestel.html#single-origin">Koffiebonen SINGLE ORIGIN</a></li>
            <li><a href="../overons/overons.html">Over ons</a></li>
            <li><a href="../klantenservice/klantenservice.html" title="">Klantenservice</a></li>
        </ul>
    </nav>
<header>
<div class="overons-titel-cont overons-titel-img" style="background-image: url(../images/img9.jpg)">
        <div class="relative container">
            <div class="row">

                <div class="col-md-8 wow animate__animated animate__fadeInDownBig" data-wow-duration="1500ms"
                data-wow-delay="100ms">
                    <h1 class="overons-titel">KLANTENSERVICE</h1>
                    <div class="overons-subtitel">
                        unieke smaken, unieke koffiebonen voor een uitzonderlijke koffie
                    </div>
                </div>


            </div>
        </div>
    </div>
</header>

    <!-- CONTACTGEGEVENS -->
    <section class="contact" id="klantenservice">

        <div class="container cont-container">
            <div class="lege-ruimte">

            </div>
            <div class="row ml-4 pl-4 mb-4">
                <div class="col-md-4 col-sm-6">
                    <div class="contact-cont relative">
                        <div class="contact-icon">
                            <i class="fal fa-envelope"></i>
                        </div>
                        <div class="contact-text">
                            <h3><span class="bold">info</span></h3>
                            <p>info@louispaulkoffiemaker.be</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="contact-cont relative">
                        <div class="contact-icon">
                            <i class="fal fa-envelope"></i>
                        </div>
                        <div class="contact-text">
                            <h3><span class="bold">verkoop</span></h3>
                            <p>sales@louispaulkoffiemaker.be</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="contact-cont relative">
                        <div class="contact-icon">
                            <i class="fal fa-envelope"></i>
                        </div>
                        <div class="contact-text">
                            <h3><span class="bold">naverkoop</span></h3>
                            <p>after-sales@louispaulkoffiemaker.be</p>
                        </div>
                    </div>
                </div>



            </div>
        </div>

    </section>

    <!-- CONTACTFORMULIER -->

    <section class="contactformuliersectie">
        <div class="container cont-form mb-4">
            <div class="row">
                <div class="col-md-12">
                    <div class="contact-formulier">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">
                                        <p class="cont-form-naam">Naam</p>
                                    </div>
                                    <div class="col-md-12">
                                        <p class="cont-form-naam">Adres</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">
                                        <p class="cont-form-naam">Bericht</p>
                                        <div class="text-right text-center-xxs">
                                            <input type="submit" value="VERSTUUR BERICHT"
                                                class="button medium gray mt-40 " style="margin-top: 25px"
                                                data-loading-text="Loading...">
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <section id="privacy">
        <div class="container">
            <h1 class="privacy">Wij nemen jouw privacy ernstig.</h1>
            <article>
                <h2>WIE WIJ ZIJN</h2>

                <p>Deze tekst is opgemaakt door Louis Paul koffiemaker, verder in de tekst afgekort tot "we" en "wij".
                </p>

                <p>Deze privacy policy is er enkel op gericht om je informatie te verschaffen met betrekking tot de
                    verwerking van persoonsgegevens in het kader van onze website : www.louispaul-koffiemaker.be. Voor
                    onze privacy praktijken met betrekking tot onze dienstverlening verwijzen wij naar de overeenkomst
                    die je met ons gesloten hebt of de contactpersoon zoals hieronder aangeduid.</p>

                <p>Jouw privacy is belangrijk voor ons. Vandaar hebben wij deze privacy policy ontwikkeld om je meer
                    informatie te verschaffen betreffende de verzameling, mededeling, overdracht en gebruik
                    (“verwerking”) van de persoonsgegevens die je met ons deelt, alsook om je meer informatie te
                    verschaffen betreffende je rechten. Wij verzoeken je dan ook om deze privacy policy door te nemen.
                </p>

                <p>Indien je vragen, opmerkingen of klachten hebt met betrekking tot deze Privacy Policy of de
                    verwerking van je persoonsgegevens of je wenst een verzoek in te dienen in overeenstemming met
                    artikel 4, gelieve dan contact op te nemen met ons per e-mail naar : info@louispaulkoffiemaker</p>

                <h2>HOE WIJ JOUW PERSOONSGEGEVENS GEBRUIKEN EN VERZAMELEN</h2>

                <p>Persoonsgegevens worden gedefinieerd als alle informatie over een geïdentificeerde of
                    identificeerbare natuurlijke persoon. Identificeerbaar verwijst naar identificators (zoals naam,
                    identificatienummer, locatiedata, etc.) die kunnen gebruikt worden om een natuurlijke persoon
                    rechtstreeks of onrechtstreeks te identificeren.</p>

                <p>De persoonsgegevens die wij verzamelen, worden verzameld voor de volgende doeleinden:</p>

                <ul>
                    <li>Indien je gebruik maakt van het contactformulier op onze website, gebruiken wij je
                        persoonsgegevens om te kunnen antwoorden op je verzoek, via e-mail of via telefoon.</li>

                    <li>Wij verwerken je persoonsgegevens met als doel je gebruikservaring te verbeteren. Dit doel
                        strekt zich uit tot het monitoren van de veiligheid, beschikbaarheid, (performance), vermogen,
                        en gezondheid van onze website.</li>

                    <li>Wij verwerken je persoonsgegevens om de toegekende rechten op basis van de toepasselijke
                        wetgeving af te dwingen of na te leven (zoals het instellen van het verdedigen tegen juridische
                        aanspraken) indien nodig. Wij kunnen je persoonsgegevens ook gebruiken om onze verplichtingen op
                        basis van de toepasselijke wetgeving na te komen.</li>
                </ul>

                <p>Wij verzamelen de volgende categorie&euml;n van persoonsgegevens:</p>

                <ul>
                    <li><em>Contactgegevens</em>: indien je gebruikt maakt van het contactformulier dan wordt je
                        gevraagd volgende informatie te verstrekken: voornaam, achternaam, e-mailadres, telefoonnummer
                        en berichtgegevens die je zelf ingeeft in het vrije vak (gelieve geen gevoelige informatie,
                        zoals gezondheidsinformatie, informatie betreffende strafrechtelijke veroordelingen, of
                        bankrekeningnummers in te geven). Dit is informatie die rechtstreeks door je verstrekt wordt.
                    </li>

                    <li><em>Gebruiksinformatie</em>: wij verwerken persoonsgegevens betreffende je gebruik van onze
                        website: IP-adres, toestel ID en type, verwijzingsbron, taalinstellingen, browser type,
                        operating system, geografische locatie, duur van het bezoek, bezochte pagina, of informatie
                        betreffende de timing, frequentie en patroon van je bezoek. Deze informatie kan geaggregeerd
                        worden en kan ons helpen om nuttige informatie te verzamelen betreffende het gebruik van de
                        website. In het geval dat dergelijke gebruiksinformatie geanonimiseerd is (en dus niet
                        herleidbaar is tot jouw als natuurlijk persoon), dan valt dergelijke informatie niet onder deze
                        Privacy Policy. Deze informatie wordt automatisch verzameld door je gebruik van de website dvm.
                        Google Analytics. Voor verdere informatie, verwijzen wij naar artikel 7 van deze Privacy Policy.
                    </li>
                </ul>

                <p>De juridische basis voor de verwerking van je persoonsgegevens is jouw toestemming. Je hebt ten allen
                    tijde het recht om je toestemming in te trekken. Dit zal geen invloed hebben op de rechtmatigheid
                    van de verwerking die gebeurde voor de intrekking van je toestemming.</p>

                <p>Je persoonsgegevens zullen enkel worden gebruikt volgens de doeleinden zoals uiteengezet in artikel
                    2.2.</p>

                <h2>BIJHOUDEN VAN JE PERSOONSGEGEVENS EN VERWIJDERING</h2>

                <p>Je persoonsgegevens zolang je je toestemming niet intrekt of zolang je zich niet verzet tegen de
                    verwerking van je persoonsgegevens. Op deze manier kunnen wij je steeds op de hoogte houden van onze
                    opleidingen, activiteiten en evenementen.</p>

                <p>Indien je je toestemming intrekt of indien je je verzet tegen de verwerking van persoonsgegevens, en
                    dergelijk verzet wordt weerhouden, dan zullen wij je persoonsgegevens verwijderen. Wij zullen
                    evenwel die persoonsgegevens, noodzakelijk om je voorkeur naar de toekomst toe te respecteren,
                    bijhouden.</p>

                <p>Wij zijn evenwel gerechtigd om je persoonsgegevens bij te houden indien dit nodig is om te voldoen
                    aan onze wettelijke verplichtingen, om een juridische aanspraak in te stellen of ons te verdedigen
                    tegen dergelijke aanspraak of voor bewijsredenen.</p>

                <h2>JE RECHTEN ALS INDIVIDU</h2>

                <p>Dit artikel bevat een overzicht van je belangrijkste rechten overeenkomstig de toepasselijke
                    wetgeving bescherming persoonsgegevens. We hebben getracht ze op een duidelijke en leesbare manier
                    voor je samen te vatten.</p>

                <p>Indien je één van je rechten wenst uit te oefenen, stuurt je ons een schriftelijk verzoek in
                    overeenstemming met artikel 1 van deze Privacy Policy. We trachten zonder onredelijke vertraging,
                    maar in elk geval binnen een termijn van één maand na ontvangst van je verzoek, op je verzoek te
                    reageren. Indien wij in de onmogelijkheid verkeren om binnen voornoemde termijn van één maand te
                    reageren en de termijn wensen te verlengen, of in geval wij geen gevolg zullen geven aan je verzoek,
                    zullen wij je daarvan in kennis stellen.</p>

                <h3><strong>Recht op inzage</strong></h3>

                <p>In het geval dat wij je persoonsgegevens verwerken, heb je recht op toegang tot je persoonsgegevens,
                    alsook tot bepaalde aanvullende informatie zoals omschreven in deze Privacy Policy.</p>

                <p>Je hebt het recht van ons een kopie te ontvangen van je persoonsgegevens die wij in ons bezit hebben,
                    op voorwaarde dat dit geen nadelige invloed heeft op de rechten en vrijheden van anderen. Het eerste
                    exemplaar wordt je kosteloos bezorgd, maar wij behouden ons het recht voor om een redelijke
                    vergoeding in rekening te brengen wanneer je om meerdere kopies verzoekt.</p>

                <h3><strong>Recht op verbetering</strong></h3>

                <p>Als de persoonsgegevens die wij over je bijhouden onjuist of onvolledig zijn, heb je het recht om ons
                    te verzoeken deze informatie te corrigeren, of om ons te verzoeken – rekening houdend met de
                    doeleinden van de verwerking – te voltooien.</p>

                <h3><strong>Recht op gegevenswissing / vergetelheid</strong></h3>

                <p>Wanneer een van de volgende gevallen van toepassing is, heb je het recht om – zonder onredelijke
                    vertraging – wissing van je persoonsgegevens te verkrijgen:</p>

                <ul>
                    <li>De persoonsgegevens zijn niet langer nodig voor de doeleinden waarvoor zij zijn verzameld of
                        anderszins verwerkt;</li>
                    <li>Je trekt jouw toestemming waarop de verwerking berust in, en er is geen andere rechtsgrond voor
                        de verwerking van je persoonsgegevens;</li>
                    <li>Je persoonsgegevens zijn onrechtmatig verwerkt;</li>
                    <li>Wissing van je persoonsgegevens is noodzakelijk om in overeenstemming te zijn met EU-recht of
                        Belgisch recht;</li>
                </ul>

                <p>Er zijn bepaalde uitsluitingen op het recht op gegevenswissing. Deze uitsluitingen omvatten waar
                    verwerking nodig is,</p>

                <ul>
                    <li>Voor het uitoefenen van het recht op vrijheid van meningsuiting en informatie;</li>
                    <li>Om redenen van algemeen belang op het gebied van volksgezondheid;</li>
                    <li>Met het oog op archivering in het algemeen belang, of statistische doeleinden;</li>
                    <li>Voor het nakomen van een wettelijke verplichting;</li>
                    <li>Voor de instelling, uitoefening of onderbouwing van een rechtsvordering.</li>
                </ul>

                <h3><strong>Recht op beperking van de verwerking</strong></h3>

                <p>Je hebt het recht de beperking van de verwerking van jouw persoonsgegevens te verkrijgen (hetgeen
                    betekent dat de persoonsgegevens alleen door ons mogen worden opgeslagen en alleen voor beperkte
                    doeleinden mogen worden gebruikt), indien één van de volgende elementen van toepassing is:</p>

                <ul>
                    <li>Je betwist de juistheid van de persoonsgegevens, gedurende een perdiode die ons in staat stelt
                        de juistheid van de persoonsgegevens te controleren;</li>
                    <li>De verwerking is onrechtmatig en je verzet je tegen het wissen van de persoonsgegevens en
                        verzoekt in de plaats daarvan om beperking van het gebruik ervan;</li>
                    <li>Wij hebben je persoonsgegevens niet meer nodig voor de verwerkingsdoeleinden, maar je hebt deze
                        nodig voor de instelling, uitoefening of onderbouwing van een rechtsvordering;</li>
                    <li>Je hebt bezwaar gemaakt tegen de verwerking, in afwachting van het antwoord op de vraag of de
                        gerechtvaardigde gronden van ons zwaarder wegen dan die van jouw.</li>
                </ul>

                <p>Naast ons recht om je persoonsgegevens op te slaan, kunnen we deze nog steeds verwerken, maar alleen:
                </p>

                <ul>
                    <li>Met je toestemming;</li>
                    <li>Voor het instellen, uitoefenen of verdedigen van een rechtsvordering;</li>
                    <li>Ter bescherming van de rechten van een andere natuurlijke of rechtspersoon;</li>
                    <li>Om redenen van openbaar belang.</li>
                </ul>

                <p>Vooraleer we de beperking van de verwerking van je persoonsgegevens opheffen, wordt je geïnformeerd.
                </p>

                <h3><strong>Recht op overdraagbaarheid van je persoonsgegevens / dataportabiliteit</strong></h3>

                <p>Indien de verwerking van je persoonsgegevens berust op jouw toestemming, en de verwerking via
                    geautomatiseerde procedés wordt verricht, heb je het recht om je persoonsgegevens te ontvangen in
                    een gestructureerde, gangbare en machineleesbare vorm. Dit recht is echter niet van toepassing, in
                    zoverre dit afbreuk zou doe naan de rechten en vrijheden van anderen.</p>

                <p>Je hebt ook het recht om je persoonsgegevens, indien dit technisch mogelijk is, rechtstreeks door ons
                    naar een ander bedrijf te laten doorzenden.</p>

                <h3><strong>Recht van bezwaar</strong></h3>

                <p>Je hebt ten allen tijde het recht om – vanwege met jouw specifieke situatie verband houdende redenen
                    – bezwaar te maken tegen de verwerking van je persoonsgegevens, maar alleen in de mate dat de
                    wettelijke basis voor de verwerking is dat de verwerking noodzakelijk is voor:</p>

                <ul>
                    <li>De uitvoering van een taak van algemeen belang of bij de uitoefening van een taak in het kader
                        van de uitoefening van het openbaar gezag dat aan ons is verleend;</li>
                    <li>De behartiging van onze gerechtvaardigde belangen of die van een derde.</li>
                    <li>Indien je bezwaar maakt tegen de verwerking van je persoonsgegevens, zullen wij de
                        persoonsgegevens niet meer verwerken, tenzij wij aantoonbare gerechtvaardigde belangen voor de
                        verwerking kunnen aantonen die zwaarder wegen dan de belangen of de grondrechten en de
                        fundamentele vrijheden van jouw.</li>
                    <li>Wanneer je persoonsgegevens worden verwerkt ten behoeve van direct marketing, ongeacht of het
                        een aanvankelijke dan wel een verdere verwerking betreft, heb je het recht ten allen tijde en
                        kosteloos bezwaar te maken tegen deze verwerking, ook in het geval van profilering voor zover
                        deze betrekking heeft op de direct marketing. Indien je zo’n bezwaar maakt, zullen wij stoppen
                        met het verwerken van je persoonsgegevens voor dit doeleinde.</li>
                </ul>

                <h3><strong>Recht om klacht in te dienen bij een toezichthoudende autoriteit</strong></h3>

                <p>Indien je van mening bent dat de door ons uitgevoerde verwerking van je persoonsgegevens in strijd is
                    met de wetgeving inzake gegevensbescherming, heb je het recht om een klacht in te dienen bij een
                    toezichthoudende autoriteit die verantwoordelijk is voor de gegevensbescherming. Je kunt dit doen in
                    de EU-lidstaat van jouw gewone verblijfplaats, van de plaats waar je werkt of van de plaats waar de
                    vermeende inbreuk heeft plaatsgevonden. In België kan je een klacht indienen bij de Privacy
                    Commissie, Drukpersstraat 35, 1000 Brussel (commission@privacycommission.be),
                    https://www.privacycommission.be/nl/contact.</p>

                <h2>HET VERSTREKKEN VAN JE PERSOONSGEGEVENS AAN DERDEN</h2>

                <p>Om onze website aan te bieden, werken wij met dienstverleners om je persoonsgegevens te verwerken en
                    op te slagen. Wij gebruiken de volgende dienstverlener: <a href="https://www.one.com"
                        target="_blank" title="Link naar website van one.com">one.com</a>.</p>

                <p>Het kan zijn dat toegang verstrekken tot je gegevens nodig is voor wettelijke doeleinden. In
                    dergelijk geval zullen wij genoodzaakt zijn om hieraan te voldoen. Wij mogen je persoonsgegevens ook
                    verstrekken indien dit nodig is om de vitale belangen van een andere natuurlijke persoon te
                    beschermen.</p>

                <h2>COOKIES</h2>

                <p>Onze website maakt gebruik van cookies.</p>

                <h3><strong>Wat zijn cookies?</strong></h3>

                <p>Cookies zijn kleine databestanden waarmee een website aan je browser vraagt om die op je computer of
                    mobiel apparaat te bewaren wanneer je de website of bepaalde pagina’s bezoekt. De cookies laten de
                    website toe om je acties of voorkeuren na verloop van tijd te ‘onthouden’. De meeste browsers
                    aanvaarden cookies, maar gebruikers kunnen hun browsers zo instellen dat deze cookies worden
                    geblokkeerd of verwijderd telkens wanneer gewenst.</p>

                <p>Cookies bevatten gewoonlijk de naam van de website waar het cookie vandaan komt, hoe lang het cookie
                    op jouw apparaat zal blijven, en een waarde, wat meestal een willekeurig gegeneerd uniek nummer is.
                </p>

                <p>Sommige cookies zullen worden verwijderd zodra je de website verlaat (de zogenaamde ‘sessiecookies’),
                    andere cookies zullen op je computer of mobiel apparaat bewaard blijven en zullen ons helpen om je
                    te identificeren als een bezoeker van onze website (de zogenaamde ‘permanente cookies’).</p>

                <h3><strong>Waarom gebruiken wij cookies?</strong></h3>

                <p>Wij gebruiken cookies om de gebruikerservaring op de website te verbeteren en om je surfgedrag in
                    kaart te brengen (bv. de pagina’s die je hebt bezocht en de tijd die je op die pagina doorbracht).
                    Cookies maken onze website gebruiksvriendelijker en staan ons toe om onze website beter af te
                    stemmen op je interesses en behoeften. Cookies worden ook gebruikt om de snelheid van je toekomstige
                    activiteiten en ervaringen op de website op te drijven.</p>

                <p>Wij gebruiken ook cookies om op anonieme wijze samengevoegde statistieken te verzamelen die ons
                    toelaten om te begrijpen hoe onze website wordt gebruikt en hoe wij onze diensten kunnen verbeteren.
                </p>

                <h3><strong>Welke cookies gebruiken wij?</strong></h3>

                <p>Wij gebruiken third party cookies. Third party cookies zijn cookies die gecreëerd zijn door andere
                    partijen (en dus niet door de website). Third party cookies op onze website zijn van Google
                    Analytics. Google Analytics is Google’s analytische tool die ons helpt te begrijpen hoe je met onze
                    website omgaat. De tool kan een reeks cookies gebruiken om informatie te verzamelen en om
                    gebruikersstatistieken over de website te rapporteren zonder individuele bezoekers aan Google
                    persoonlijk kenbaar te maken. Meer gedetailleerde informatie, in het Engels, is beschikbaar op <a
                        href="https://developers.google.com/analytics/devguides/collection/analyticsjs/cookie-usage"
                        target="_blank"
                        title="Link naar website van Google Analytics">https://developers.google.com/analytics/devguides/collection/analyticsjs/cookie-usage</a>.
                </p>

                <h2>AANPASSINGEN AAN DE PRIVACY POLICY</h2>

                <p>Van tijd tot tijd kunnen wij wijzigingen aanbrengen aan deze privacy policy. De meest recente versie
                    van de privacy policy kan altijd geconsulteerd worden op de website.</p>
            </article>
        </div> <!-- container -->
    </section>
    <section id="algvw">

        <div class="container">



            <h1 class="algvw">Algemene Voorwaarden</h1>

            <article>
                <h2>Artikel 1 - Identiteit van de ondernemer</h2>

                <p>Passe Partout, Polderdreef 48, 9120 Beveren</p>

                <!-- <p>Tel 0476 65 48 33 (bereikbaar van dinsdag tem vrijdag van 9u tot 18u)</p> -->

                <p>E-mailadres: info@louispaulkoffiemaker</p>

                <p><strong>Btw-identificatienummer:</strong> BE 0460 640 033</p>

                <h2>Artikel 2 - Toepasselijkheid</h2>

                <p>Deze algemene voorwaarden zijn van toepassing op elk aanbod van de ondernemer en op elke tot
                    stand gekomen overeenkomst op afstand en bestellingen tussen ondernemer en consument.<br>
                    Voordat de overeenkomst op afstand wordt gesloten, wordt de tekst van deze algemene voorwaarden
                    aan de consument beschikbaar gesteld. Indien dit redelijkerwijs niet mogelijk is, zal voordat de
                    overeenkomst op afstand wordt gesloten, worden aangegeven dat de algemene voorwaarden bij de
                    ondernemer zijn in te zien en zij op verzoek van de consument zo spoedig mogelijk kosteloos
                    worden toegezonden.<br>
                    Indien de overeenkomst op afstand elektronisch wordt gesloten, kan in afwijking van het vorige
                    lid en voordat de overeenkomst op afstand wordt gesloten, de tekst van deze algemene voorwaarden
                    langs elektronische weg aan de consument ter beschikking worden gesteld op zodanige wijze dat
                    deze door de consument op een eenvoudige manier kan worden opgeslagen op een duurzame
                    gegevensdrager. Indien dit redelijkerwijs niet mogelijk is, zal voordat de overeenkomst op
                    afstand wordt gesloten, worden aangegeven waar van de algemene voorwaarden langs elektronische
                    weg kan worden kennisgenomen en dat zij op verzoek van de consument langs elektronische weg of
                    op andere wijze kosteloos zullen worden toegezonden.<br>
                    Voor het geval dat naast deze algemene voorwaarden tevens specifieke product- of
                    dienstenvoorwaarden van toepassing zijn, is het tweede en derde lid van overeenkomstige
                    toepassing en kan de consument zich in geval van tegenstrijdige algemene voorwaarden steeds
                    beroepen op de toepasselijke bepaling die voor hem het meest gunstig is.<br>
                    Indien één of meerdere bepalingen in deze algemene voorwaarden op enig moment geheel of
                    gedeeltelijk nietig zijn of vernietigd worden, dan blijft de overeenkomst en deze voorwaarden
                    voor het overige in stand en zal de betreffende bepaling in onderling overleg onverwijld
                    vervangen worden door een bepaling dat de strekking van het oorspronkelijke zoveel mogelijk
                    benaderd.<br>
                    Situaties die niet in deze algemene voorwaarden zijn geregeld, dienen te worden beoordeeld ‘naar
                    de geest’ van deze algemene voorwaarden.<br>
                    Onduidelijkheden over de uitleg of inhoud van één of meerdere bepalingen van onze voorwaarden,
                    dienen uitgelegd te worden ‘naar de geest’ van deze algemene voorwaarden.</p>

                <h2>Artikel 3 - Het aanbod</h2>

                <p>Indien een aanbod een beperkte geldigheidsduur heeft of onder voorwaarden geschiedt, wordt dit
                    nadrukkelijk in het aanbod vermeld.<br>
                    Het aanbod is vrijblijvend. De ondernemer is gerechtigd het aanbod te wijzigen en aan te
                    passen.<br>
                    Het aanbod bevat een volledige en nauwkeurige omschrijving van de aangeboden producten en/of
                    diensten. De beschrijving is voldoende gedetailleerd om een goede beoordeling van het aanbod
                    door de consument mogelijk te maken. Als de ondernemer gebruik maakt van afbeeldingen zijn deze
                    een waarheidsgetrouwe weergave van de aangeboden producten en/of diensten. Kennelijke
                    vergissingen of kennelijke fouten in het aanbod binden de ondernemer niet.<br>
                    Alle afbeeldingen, specificaties gegevens in het aanbod zijn indicatie en kunnen geen aanleiding
                    zijn tot schadevergoeding of ontbinding van de overeenkomst.<br>
                    Afbeeldingen bij producten zijn een waarheidsgetrouwe weergave van de aangeboden producten.
                    Ondernemer kan niet garanderen dat de weergegeven kleuren exact overeenkomen met de echte
                    kleuren van de producten.<br>
                    Elk aanbod bevat zodanige informatie, dat voor de consument duidelijk is wat de rechten en
                    verplichtingen zijn, die aan de aanvaarding van het aanbod zijn verbonden. Dit betreft in het
                    bijzonder:</p>

                <ul>
                    <li>de prijs inclusief belastingen;</li>
                    <li>de eventuele kosten van verzending;</li>
                    <li>de wijze waarop de overeenkomst tot stand zal komen en welke handelingen daarvoor nodig
                        zijn;</li>
                    <li>het al dan niet van toepassing zijn van het herroepingsrecht;</li>
                    <li>de wijze van betaling, aflevering en uitvoering van de overeenkomst;</li>
                    <li>de termijn voor aanvaarding van het aanbod, dan wel de termijn waarbinnen de ondernemer de
                        prijs garandeert;</li>
                    <li>de hoogte van het tarief voor communicatie op afstand indien de kosten van het gebruik van
                        de techniek voor communicatie op afstand worden berekend op een andere grondslag dan het
                        reguliere basistarief voor het gebruikte communicatiemiddel;</li>
                    <li>of de overeenkomst na de totstandkoming wordt gearchiveerd, en zo ja op welke wijze deze
                        voor de consument te raadplegen is;</li>
                    <li>de manier waarop de consument, voor het sluiten van de overeenkomst, de door hem in het
                        kader van de overeenkomst verstrekte gegevens kan controleren en indien gewenst herstellen;
                    </li>
                    <li>de eventuele andere talen waarin, naast het Nederlands, de overeenkomst kan worden gesloten;
                    </li>
                    <li>de gedragscodes waaraan de ondernemer zich heeft onderworpen en de wijze waarop de consument
                        deze gedragscodes langs elektronische weg kan raadplegen; en</li>
                    <li>de minimale duur van de overeenkomst op afstand in geval van een duurtransactie.</li>
                    <li>Optioneel: beschikbare maten, kleuren, soort materialen.</li>
                </ul>

                <h2>Artikel 4 - De overeenkomst</h2>

                <p>De overeenkomst komt, onder voorbehoud van het bepaalde in lid 4, tot stand op het moment van
                    aanvaarding door de consument van het aanbod en het voldoen aan de daarbij gestelde
                    voorwaarden.<br>
                    Indien de consument het aanbod langs elektronische weg heeft aanvaard, bevestigt de ondernemer
                    onverwijld langs elektronische weg de ontvangst van de aanvaarding van het aanbod. Zolang de
                    ontvangst van deze aanvaarding niet door de ondernemer is bevestigd, kan de consument de
                    overeenkomst ontbinden.<br>
                    Indien de overeenkomst elektronisch tot stand komt, treft de ondernemer passende technische en
                    organisatorische maatregelen ter beveiliging van de elektronische overdracht van data en zorgt
                    hij voor een veilige webomgeving. Indien de consument elektronisch kan betalen, zal de
                    ondernemer daartoe passende veiligheidsmaatregelen in acht nemen.<br>
                    De ondernemer kan zich - binnen wettelijke kaders - op de hoogte stellen of de consument aan
                    zijn betalingsverplichtingen kan voldoen, evenals van al die feiten en factoren die van belang
                    zijn voor een verantwoord aangaan van de overeenkomst op afstand. Indien de ondernemer op grond
                    van dit onderzoek goede gronden heeft om de overeenkomst niet aan te gaan, is hij gerechtigd
                    gemotiveerd een bestelling of aanvraag te weigeren of aan de uitvoering bijzondere voorwaarden
                    te verbinden.<br>
                    De ondernemer zal bij het product of dienst aan de consument de volgende informatie,
                    schriftelijk of op zodanige wijze dat deze door de consument op een toegankelijke manier kan
                    worden opgeslagen op een duurzame gegevensdrager, meesturen:</p>

                <p>a. het bezoekadres van de vestiging van de ondernemer waar de consument met klachten terecht kan;
                </p>

                <p>b. de voorwaarden waaronder en de wijze waarop de consument van het herroepingsrecht gebruik kan
                    maken, dan wel een duidelijke melding inzake het uitgesloten zijn van het herroepingsrecht;</p>

                <p>c. de informatie over garanties en bestaande service na aankoop;</p>

                <p>d. de in artikel 4 lid 3 van deze voorwaarden opgenomen gegevens, tenzij de ondernemer deze
                    gegevens al aan de consument heeft verstrekt vóór de uitvoering van de overeenkomst;</p>

                <p>e. de vereisten voor opzegging van de overeenkomst indien de overeenkomst een duur heeft van meer
                    dan één jaar of van onbepaalde duur is.</p>

                <p>In geval van een duurtransactie is de bepaling in het vorige lid slechts van toepassing op de
                    eerste levering.<br>
                    Iedere overeenkomst wordt aangegaan onder de opschortende voorwaarden van voldoende
                    beschikbaarheid van de betreffende producten.</p>

                <h2>Artikel 5 - Herroepingsrecht</h2>

                <p>Bij de aankoop van producten heeft de consument de mogelijkheid de overeenkomst zonder opgave van
                    redenen te ontbinden gedurende 14 dagen. Deze bedenktermijn gaat in op de dag na ontvangst van
                    het product door de consument of een vooraf door de consument aangewezen en aan de ondernemer
                    bekend gemaakte vertegenwoordiger.<br>
                    Tijdens de bedenktijd zal de consument zorgvuldig omgaan met het product en de verpakking. Hij
                    zal het product slechts in die mate uitpakken of gebruiken voor zover dat nodig is om te kunnen
                    beoordelen of hij het product wenst te behouden. Indien hij van zijn herroepingsrecht gebruik
                    maakt, zal hij het product met alle geleverde toebehoren en - indien redelijkerwijze mogelijk -
                    in de originele staat en verpakking aan de ondernemer retourneren, conform de door de ondernemer
                    verstrekte redelijke en duidelijke instructies.<br>
                    Wanneer de consument gebruik wenst te maken van zijn herroepingsrecht is hij verplicht dit
                    binnen 14 dagen, na ontvangst van het product, kenbaar te maken aan de ondernemer. Het kenbaar
                    maken dient de consument te doen middels het modelformulier. Nadat de consument kenbaar heeft
                    gemaakt gebruik te willen maken van zijn herroepingsrecht dient de klant het product binnen 14
                    dagen retour te sturen. De consument dient te bewijzen dat de geleverde zaken tijdig zijn
                    teruggestuurd, bijvoorbeeld door middel van een bewijs van verzending.<br>
                    Indien de klant na afloop van de in lid 2 en 3 genoemde termijnen niet kenbaar heeft gemaakt
                    gebruik te willen maken van zijn herroepingsrecht resp. het product niet aan de ondernemer heeft
                    teruggezonden, is de koop een feit.</p>

                <h2>Artikel 6 - Kosten in geval van herroeping</h2>

                <p>Indien de consument gebruik maakt van zijn herroepingsrecht, komen ten hoogste de kosten van
                    terugzending voor zijn rekening.<br>
                    Indien de consument een bedrag betaald heeft, zal de ondernemer dit bedrag zo spoedig mogelijk,
                    doch uiterlijk binnen 14 dagen na herroeping, terugbetalen. Hierbij is wel de voorwaarde dat het
                    product reeds terug ontvangen is door de webwinkelier of sluitend bewijs van complete
                    terugzending overlegd kan worden.</p>

                <h2>Artikel 7 - Uitsluiting herroepingsrecht</h2>

                <p>De ondernemer kan het herroepingsrecht van de consument uitsluiten voor producten zoals
                    omschreven in lid 2 en 3. De uitsluiting van het herroepingsrecht geldt slechts indien de
                    ondernemer dit duidelijk in het aanbod, althans tijdig voor het sluiten van de overeenkomst,
                    heeft vermeld.<br>
                    Uitsluiting van het herroepingsrecht is slechts mogelijk voor producten:</p>

                <p>a. die door de ondernemer tot stand zijn gebracht overeenkomstig specificaties van de consument;
                </p>

                <p>b. die duidelijk persoonlijk van aard zijn;</p>

                <p>c. die door hun aard niet kunnen worden teruggezonden;</p>

                <p>d. die snel kunnen bederven of verouderen;</p>

                <p>e. waarvan de prijs gebonden is aan schommelingen op de financiële markt waarop de ondernemer
                    geen invloed heeft;</p>

                <p>f. voor losse kranten en tijdschriften;</p>

                <p>g. voor audio- en video-opnamen en computersoftware waarvan de consument de verzegeling heeft
                    verbroken.</p>

                <p>h. voor hygiënische producten waarvan de consument de verzegeling heeft verbroken.</p>

                <p>Uitsluiting van het herroepingsrecht is slechts mogelijk voor diensten:</p>

                <p>a. betreffende logies, vervoer, restaurantbedrijf of vrijetijdsbesteding te verrichten op een
                    bepaalde datum of tijdens een bepaalde periode;</p>

                <p>b. waarvan de levering met uitdrukkelijke instemming van de consument is begonnen voordat de
                    bedenktijd is verstreken;</p>

                <p>c. betreffende weddenschappen en loterijen.</p>

                <h2>Artikel 8 - De prijs</h2>

                <p>Gedurende de in het aanbod vermelde geldigheidsduur worden de prijzen van de aangeboden producten
                    en/of diensten niet verhoogd, behoudens prijswijzigingen als gevolg van veranderingen in
                    btw-tarieven.<br>
                    In afwijking van het vorige lid kan de ondernemer producten of diensten waarvan de prijzen
                    gebonden zijn aan schommelingen op de financiële markt en waar de ondernemer geen invloed op
                    heeft, met variabele prijzen aanbieden. Deze gebondenheid aan schommelingen en het feit dat
                    eventueel vermelde prijzen richtprijzen zijn, worden bij het aanbod vermeld.<br>
                    Prijsverhogingen binnen 3 maanden na de totstandkoming van de overeenkomst zijn alleen
                    toegestaan indien zij het gevolg zijn van wettelijke regelingen of bepalingen.<br>
                    Prijsverhogingen vanaf 3 maanden na de totstandkoming van de overeenkomst zijn alleen toegestaan
                    indien de ondernemer dit bedongen heeft en:</p>

                <p>a. deze het gevolg zijn van wettelijke regelingen of bepalingen; of</p>

                <p>b. de consument de bevoegdheid heeft de overeenkomst op te zeggen met ingang van de dag waarop de
                    prijsverhoging ingaat.</p>

                <p>De in het aanbod van producten of diensten genoemde prijzen zijn inclusief btw.<br>
                    Alle prijzen zijn onder voorbehoud van druk – en zetfouten. Voor de gevolgen van druk – en
                    zetfouten wordt geen aansprakelijkheid aanvaard. Bij druk – en zetfouten is de ondernemer niet
                    verplicht het product volgens de foutieve prijs te leveren.</p>

                <h2>Artikel 11 - Conformiteit en Garantie</h2>

                <p>De ondernemer staat er voor in dat de producten en/of diensten voldoen aan de overeenkomst, de in
                    het aanbod vermelde specificaties, aan de redelijke eisen van deugdelijkheid en/of bruikbaarheid
                    en de op de datum van de totstandkoming van de overeenkomst bestaande wettelijke bepalingen
                    en/of overheidsvoorschriften. Indien overeengekomen staat de ondernemer er tevens voor in dat
                    het product geschikt is voor ander dan normaal gebruik.<br>
                    Een door de ondernemer, fabrikant of importeur verstrekte garantie doet niets af aan de
                    wettelijke rechten en vorderingen die de consument op grond van de overeenkomst tegenover de
                    ondernemer kan doen gelden.<br>
                    Eventuele gebreken of verkeerd geleverde producten dienen binnen X dagen/weken na levering aan
                    de ondernemer schriftelijk te worden gemeld. Terugzending van de producten dient te geschieden
                    in de originele verpakking en in nieuwstaat verkerend.<br>
                    De garantietermijn van de ondernemer komt overeen met de fabrieksgarantietermijn. De ondernemer
                    is echter te nimmer verantwoordelijk voor de uiteindelijke geschiktheid van de producten voor
                    elke individuele toepassing door de consument, noch voor eventuele adviezen ten aanzien van het
                    gebruik of de toepassing van de producten.<br>
                    De garantie geldt niet indien:</p>

                <p>De consument de geleverde producten zelf heeft gerepareerd en/of bewerkt of door derden heeft
                    laten repareren en/of bewerken;<br>
                    De geleverde producten aan abnormale omstandigheden zijn blootgesteld of anderszins onzorgvuldig
                    worden behandeld of in strijd zijn met de aanwijzingen van de ondernemer en/of op de verpakking
                    behandeld zijn;<br>
                    De ondeugdelijkheid geheel of gedeeltelijk het gevolg is van voorschriften die de overheid heeft
                    gesteld of zal stellen ten aanzien van de aard of de kwaliteit van de toegepaste materialen.</p>

                <h2>Artikel 12 - Levering en uitvoering</h2>

                <p>De ondernemer zal de grootst mogelijke zorgvuldigheid in acht nemen bij het in ontvangst nemen en
                    bij de uitvoering van bestellingen van producten en bij de beoordeling van aanvragen tot
                    verlening van diensten.<br>
                    Als plaats van levering geldt het adres dat de consument aan het bedrijf kenbaar heeft
                    gemaakt.<br>
                    Met inachtneming van hetgeen hierover in lid 4 van dit artikel is vermeld, zal het bedrijf
                    geaccepteerde bestellingen met bekwame spoed doch uiterlijk binnen 30 dagen uitvoeren, tenzij
                    consument akkoord is gegaan met een langere leveringstermijn. Indien de bezorging vertraging
                    ondervindt, of indien een bestelling niet dan wel slechts gedeeltelijk kan worden uitgevoerd,
                    ontvangt de consument hiervan uiterlijk 30 dagen nadat hij de bestelling geplaatst heeft
                    bericht. De consument heeft in dat geval het recht om de overeenkomst zonder kosten te
                    ontbinden. De consument heeft geen recht op een schadevergoeding.<br>
                    Alle levertermijnen zijn indicatief. Aan eventuele genoemde termijnen kan de consument geen
                    rechten ontlenen. Overschrijding van een termijn geeft de consument geen recht op
                    schadevergoeding.<br>
                    In geval van ontbinding conform het lid 3 van dit artikel zal de ondernemer het bedrag dat de
                    consument betaald heeft zo spoedig mogelijk, doch uiterlijk binnen 14 dagen na ontbinding,
                    terugbetalen.<br>
                    Indien levering van een besteld product onmogelijk blijkt te zijn, zal de ondernemer zich
                    inspannen om een vervangend artikel beschikbaar te stellen. Uiterlijk bij de bezorging zal op
                    duidelijke en begrijpelijke wijze worden gemeld dat een vervangend artikel wordt geleverd. Bij
                    vervangende artikelen kan het herroepingsrecht niet worden uitgesloten. De kosten van een
                    eventuele retourzending zijn voor rekening van de ondernemer.<br>
                    Het risico van beschadiging en/of vermissing van producten berust bij de ondernemer tot het
                    moment van bezorging aan de consument of een vooraf aangewezen en aan de ondernemer bekend
                    gemaakte vertegenwoordiger, tenzij uitdrukkelijk anders is overeengekomen.</p>

                <h2>Artikel 13 - Duurtransacties: duur, opzegging en verlenging</h2>

                <h3 class="bold">EEN ABONNEMENT BIJ LOUIS PAUL KOFFIEMAKER</h3>
                <p>Contracteren met Louis Paul koffiemaker geschiedt uitsluitend op afstand. Tussen Louis Paul koffiemaker en klant komt een overeenkomst, al dan niet zijnde een abonnement, tot stand via de website op het moment dat de klant een bestelling plaatst, of kenbaar maakt een aanbieding of offerte van Louis Paul koffiemake te accepteren.</p><br>

                <h3>Opzegging</h3>

                <p>De consument kan een overeenkomst die voor onbepaalde tijd is aangegaan en die strekt tot het
                    geregeld afleveren van producten (elektriciteit daaronder begrepen) of diensten, te allen tijde
                    opzeggen met inachtneming van daartoe overeengekomen opzeggingsregels en een opzegtermijn van
                    ten hoogste één maand.<br>
                    De consument kan een overeenkomst die voor bepaalde tijd is aangegaan en die strekt tot het
                    geregeld afleveren van producten (elektriciteit daaronder begrepen) of diensten, te allen tijde
                    tegen het einde van de bepaalde duur opzeggen met inachtneming van daartoe overeengekomen
                    opzeggingsregels en een opzegtermijn van ten hoogste één maand.<br>
                    De consument kan de in de vorige leden genoemde overeenkomsten:</p>

                <p>te allen tijde opzeggen en niet beperkt worden tot opzegging op een bepaald tijdstip of in een
                    bepaalde periode;<br>
                    tenminste opzeggen op dezelfde wijze als zij door hem zijn aangegaan;<br>
                    altijd opzeggen met dezelfde opzegtermijn als de ondernemer voor zichzelf heeft bedongen.</p>

                <h3>Verlenging</h3>

                <p>Een overeenkomst die voor bepaalde tijd is aangegaan en die strekt tot het geregeld afleveren van
                    producten (elektriciteit daaronder begrepen) of diensten, mag niet stilzwijgend worden verlengd
                    of vernieuwd voor een bepaalde duur.<br>
                    In afwijking van het vorige lid mag een overeenkomst die voor bepaalde tijd is aangegaan en die
                    strekt tot het geregeld afleveren van dag- nieuws- en weekbladen en tijdschriften stilzwijgend
                    worden verlengd voor een bepaalde duur van maximaal drie maanden, als de consument deze
                    verlengde overeenkomst tegen het einde van de verlenging kan opzeggen met een opzegtermijn van
                    ten hoogste één maand.<br>
                    Een overeenkomst die voor bepaalde tijd is aangegaan en die strekt tot het geregeld afleveren
                    van producten of diensten, mag alleen stilzwijgend voor onbepaalde duur worden verlengd als de
                    consument te allen tijde mag opzeggen met een opzegtermijn van ten hoogste één maand en een
                    opzegtermijn van ten hoogste drie maanden in geval de overeenkomst strekt tot het geregeld, maar
                    minder dan eenmaal per maand, afleveren van dag-, nieuws- en weekbladen en tijdschriften.<br>
                    Een overeenkomst met beperkte duur tot het geregeld ter kennismaking afleveren van dag-, nieuws-
                    en weekbladen en tijdschriften (proef- of kennismakingsabonnement) wordt niet stilzwijgend
                    voortgezet en eindigt automatisch na afloop van de proef- of kennismakingsperiode.</p>

                <h3>Duur</h3>

                <p>Als een overeenkomst een duur van meer dan een jaar heeft, mag de consument na een jaar de
                    overeenkomst te allen tijde met een opzegtermijn van ten hoogste een maand opzeggen, tenzij de
                    redelijkheid en billijkheid zich tegen opzegging vóór het einde van de overeengekomen duur
                    verzetten.</p>

                <h2>Artikel 12 - Betaling</h2>

                <p>Voor zover niet anders is overeengekomen, dienen de door de consument verschuldigde bedragen te
                    worden voldaan binnen 7 werkdagen na het ingaan van de bedenktermijn als bedoeld in artikel 6
                    lid 1. In geval van een overeenkomst tot het verlenen van een dienst, vangt deze termijn aan
                    nadat de consument de bevestiging van de overeenkomst heeft ontvangen.<br>
                    De consument heeft de plicht om onjuistheden in verstrekte of vermelde betaalgegevens onverwijld
                    aan de ondernemer te melden.<br>
                    In geval van wanbetaling van de consument heeft de ondernemer behoudens wettelijke beperkingen,
                    het recht om de vooraf aan de consument kenbaar gemaakte redelijke kosten in rekening te
                    brengen.</p>

                <h2>Artikel 13 - Klachtenregeling</h2>

                <p>De ondernemer beschikt over een voldoende bekend gemaakte klachtenprocedure en behandelt de
                    klacht overeenkomstig deze klachtenprocedure.<br>
                    Klachten over de uitvoering van de overeenkomst moeten binnen 7 dagen volledig en duidelijk
                    omschreven worden ingediend bij de ondernemer, nadat de consument de gebreken heeft
                    geconstateerd.<br>
                    Bij de ondernemer ingediende klachten worden binnen een termijn van 14 dagen gerekend vanaf de
                    datum van ontvangst beantwoord. Als een klacht een voorzienbaar langere verwerkingstijd vraagt,
                    wordt door de ondernemer binnen de termijn van 14 dagen geantwoord met een bericht van ontvangst
                    en een indicatie wanneer de consument een meer uitvoerig antwoord kan verwachten.<br>
                    Indien de klacht niet in onderling overleg kan worden opgelost ontstaat een geschil dat vatbaar
                    is voor de geschillenregeling.<br>
                    Klachten die niet in onderling overleg opgelost kunnen worden dient de consument zich te wenden
                    tot Stichting WebwinkelKeur (www.webwinkelkeur.nl), deze zal gratis bemiddelen. Mocht er dan nog
                    niet tot een oplossing gekomen worden, heeft de consument de mogelijkheid om zijn klacht door
                    Stichting GeschilOnline te laten behandelen, de uitspraak hiervan is bindend en zowel ondernemer
                    als consument stemmen in met deze bindende uitspraak. Aan het voorleggen van een geschil aan
                    deze geschillencommissie zijn kosten verbonden die door de consument betaalt dienen te worden
                    aan de betreffende commissie.<br>
                    Een klacht schort de verplichtingen van de ondernemer niet op, tenzij de ondernemer schriftelijk
                    anders aangeeft.<br>
                    Indien een klacht gegrond wordt bevonden door de ondernemer, zal de ondernemer naar haar keuze
                    of de geleverde producten kosteloos vervangen of repareren.</p>

                <h2>Artikel 14 - Geschillen</h2>

                <p>Op overeenkomsten tussen de ondernemer en de consument waarop deze algemene voorwaarden
                    betrekking hebben, is uitsluitend Nederlands recht van toepassing. Ook indien de consument
                    woonachtig is in het buitenland.<br>
                    Het Weens Koopverdrag is niet van toepassing.</p>

                <h2>Artikel 15 - Aanvullende of afwijkende bepalingen</h2>

                <p>Aanvullende dan wel van deze algemene voorwaarden afwijkende bepalingen mogen niet ten nadele van
                    de consument zijn en dienen schriftelijk te worden vastgelegd dan wel op zodanige wijze dat deze
                    door de consument op een toegankelijke manier kunnen worden opgeslagen op een duurzame
                    gegevensdrager.</p>


            </article>
        </div>



    </section>
    <footer class="mainfooter">
        <div class="container">
            <p><strong>&copy; Louis Paul koffiemaker, 2020. </strong> Alle rechten voorbehouden. | <a href="#privacy"
                    title="Link naar de Privacy Policy van deze website" class="button">Privacy Policy</a>.</p>
        </div> <!-- container -->
    </footer>
    <!-- SHOP INFO 1 -->
    <div class="shop-info">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 text-center">
                    <a href="../index.html#bestelvw" class="badge badge-light">Min bestelhoeveelheid
                        4x250 gr</a>
                </div>
                <div class="col-md-3 col-sm-6 text-center">
                    <a href="../index.html#bestelvw" class="badge badge-light">Levering: 1-3 dagen</a>
                </div>
                <div class="col-md-3 col-sm-6 text-center">
                    <a href="../index.html#bestelvw" class="badge badge-light">Gratis levering vanaf
                        €70</a>
                </div>
                <div class="col-md-3 col-sm-6 text-center">
                    <a href="../klantenservice/klantenservice.html" class="badge badge-light text-left">Klantenservice | Privacy Policy | Alg Voorw</a>
                </div>
            </div>
        </div>
    </div>


    <?php wp_footer();?>
</body>

</html>